# HGI

HGI is a coding-agent prototype that performs read-only exploration while a
user is still typing, then reuses the resulting evidence after the user
explicitly commits the request.

## Run

```bash
# This workspace uses the existing Conda Python311 interpreter as its base.
/home/ethereal/vm2/conda/anaconda3/envs/Python311/bin/python -m venv .venv
. .venv/bin/activate
pip install -e '.[dev]'
hgi --workspace /path/to/project
```

The checked-in defaults use the existing Codex Responses provider without
copying its API key: `gpt-5.6-luna` with `low` reasoning effort. HGI reads the
provider from `~/.codex/config.toml` and authentication from
`~/.codex/auth.json`. Use `--provider anthropic --model <model>` to select the
Anthropic adapter instead.

Type a request and press Enter to commit it. `Esc` cancels the current run;
`Ctrl-C` exits. The default manual mode never commits a request on the user's
behalf. Writes require confirmation unless `--writes allow` is supplied.

Runtime artifacts are stored below `<workspace>/.hgi/` and are excluded from
speculative searches.

Explorer tool results are also captured as in-memory partial artifacts. If the
user commits before exploration finishes, HGI passes the completed file
inventory, search matches, and source excerpts to the committed agent before
cancelling the remaining speculative work. After a successful read-only
commit, source-backed partial evidence is retained as a provisional artifact
for one hour so a near-term follow-up can reuse it. Source evidence read by a
successful committed read-only run is merged into the same provisional cache.

When a user summary covers the current draft, Commit sends that concise intent
to the committed agent instead of replaying the full draft. Any input newer
than the summary is appended verbatim. If no matching summary exists, Commit
falls back to the original request.

Committed tool results have a 16,000-character cumulative context budget. A
batch of parallel results shares the remaining budget so one large file cannot
hide every later result; truncated results tell the agent to retry with a
narrower query. Once the budget is exhausted, tools are disabled and the agent
must answer from the evidence already collected.

Semantically similar exploration goals reuse the active Explorer instead of
restarting it when later input only restates the request or adds background.
The Explorer has a three-turn soft budget: it may continue while new source
evidence is still arriving, but must finish within six turns and 24,000
cumulative tool-result characters. Commit does not wait for a redundant
user-summary model call.

High-confidence source evidence is persisted with file hashes. Later
explorations receive unchanged evidence directly and focus on unresolved or
stale paths. Changed files invalidate their cached evidence, low-quality
partials are not persisted, and a new artifact replaces older artifacts for
the same goal so the cache does not grow without bound.

Cache retrieval removes generic request wording and selects only evidence from
paths that match the current query. A broad prior exploration can therefore
reuse incidental relevant evidence without injecting its unrelated findings.

Successful committed edits trigger an asynchronous cache refresh after the
answer is returned. Evidence for files changed by `write_file` or
`run_command` is removed immediately, while evidence for unchanged files is
retained. New user input cancels an in-flight refresh so foreground work keeps
priority. Each refresh attempt is capped at 30 seconds and one delayed retry is
allowed by default. External edits are still caught lazily by stored hashes.

Read tools exclude credentials and generated dependency trees, including
`.env`, `.venv`, `.git`, caches, `node_modules`, and symlinks that resolve
outside the workspace. Public templates such as `.env.example` remain visible.

## Logs

Structured JSONL logs are written asynchronously to
`<workspace>/.hgi/logs/hgi.jsonl`. They include session/run/generation IDs,
model and tool latency, lifecycle status, and provider token usage (input,
cached input, output, and reasoning). Files rotate at 10 MB with five backups
by default. Prompt text, responses, source excerpts, command arguments, API
keys, and error messages are redacted.

```bash
tail -f .hgi/logs/hgi.jsonl
hgi --log-level DEBUG --log-max-bytes 20000000 --log-backups 10
jq 'select(.event == "run.completed") | {run_id, duration_ms, usage, usage_by_component, metrics}' \
  .hgi/logs/hgi.jsonl
```

Use `--no-file-log` to disable file logging.

## Evaluation

The consolidated scenario test report, including Baseline versus Speculate
latency, token, cost, and quality comparisons, is available in
[`docs/SCENARIO_TEST_REPORT.md`](docs/SCENARIO_TEST_REPORT.md).
