# HGI 实现与评测汇总

更新日期：2026-10-04

## 1. 结论

HGI 第一版已经实现并可通过交互式 CLI 使用。系统能够在用户输入期间启动只读探索，保存完整或阶段性 Artifact，并在正式提交后将证据注入 Committed Agent。

使用 `gpt-5.6-luna`、`low` reasoning 的单轮真实 A/B 测试中，15 秒输入窗口下的提交后延迟从 62.136 秒降至 46.948 秒，降低 24.4%。投机组总 token 从 187,086 降至 176,603，但由于缓存命中更少，按 OpenAI 标准单价估算的金额从 $0.03067 上升至 $0.03325，增加约 8.4%。

这说明当前实现已经验证了核心假设：后台探索可以降低 Enter 后的等待时间；代价是更多模型请求、更高未缓存输入量，以及在部分工作负载上略高的实际费用。

## 2. 已实现功能

### 输入与控制

- 逐次接收输入 Buffer 变化。
- 在句号、问号、感叹号、分号、换行或停顿后触发 Judge。
- 支持 `manual`、`assist`、`auto` Commit 模式。
- 用户 Commit 和 Stop 始终优先于 Judge。
- 使用 generation 隔离迟到的 Explorer 结果。

### Judge 与 Summary

- Judge 返回 `wait`、`summarize_and_wait`、`explore` 或 `commit`。
- User Summary 只消费用户输入，不混入工具或 Agent 输出。
- Judge 决定探索后，Explorer 和 Summary 并行启动，避免串行增加首轮探索延迟。
- Judge 被提示在后续输入只改写目标或增加无关背景时返回 `wait`。
- Commit 不阻塞等待重复的 Summary 调用；已有摘要覆盖当前输入时只传摘要，未摘要的最新输入原样追加，摘要不可用时回退完整 request。

### Explorer

- 使用独立 Agent 上下文。
- Dispatcher 只注册 `read_file`、`glob_files`、`grep`、`git_diff` 和 `read_artifact`。
- 不注册写文件或命令执行工具。
- 输出带路径、行号、claim、源码摘录、置信度和未解决问题的 Artifact。
- 每次只读工具返回后实时生成 partial Artifact。
- 用户在最终探索摘要生成前提交时，已完成的目录、搜索和源码证据仍可复用。
- 相似目标由技术标识符和中英文词项覆盖率去重，不取消已有 Explorer 或清空 partial Artifact。
- 默认 3 次模型调用为软预算；仍产生新源码证据时可继续，但最多 6 次，最后一轮关闭工具并强制收尾。
- 单次探索注入模型的工具结果累计不超过 24,000 字符。

### Speculative Buffer

- 完整 Artifact 保存为普通 JSON 文件。
- 短索引保存为 JSONL。
- 使用关键词、代码路径、英文前缀、中文双字词、新鲜度和置信度筛选候选项。
- 正式提交时直接把选中的完整 Artifact 注入 Committed Agent，不额外调用 `read_artifact`。
- 只持久化达到置信度门槛且包含真实源码位置或摘录的 Artifact；纯文件清单不进入缓存。
- 成功只读提交会合并 Explorer partial 和 Committed Agent 实际读取的源码，保存为一小时有效的 provisional Artifact，使短输入窗口也能服务近期追问。
- 检索过滤通用请求词，并对命中的宽泛 Artifact 按路径裁剪 Evidence；持久化原件保持完整。
- Evidence 保存文件 SHA-256；文件变化后对应证据从正式复用集合中移除，并作为 stale unresolved 交给 Explorer 刷新。
- `write_file` 精确报告实际内容变化；`run_command` 通过命令前后的文件元数据快照报告创建、修改和删除路径。
- 修改发生时同步移除受影响 Evidence 并保留其他文件证据；成功提交返回后异步刷新 stale Artifact，不阻塞当前答案。
- 新用户输入、下一次 Commit 或 Stop 会取消后台刷新；失败或取消的正式任务不会启动刷新。
- 后台刷新默认单次最多 30 秒，失败后延迟 3 秒重试一次，避免 provider 长时间挂起。
- 后续 Explorer 直接获得未过期的完整 Artifact；内部哈希不进入模型上下文。
- 同主题的新高质量 Artifact 成功落盘后替换旧版本，避免重复证据持续扩大上下文。

### Committed Agent

- 具备读取、权限控制写文件和参数化命令执行能力。
- 命令使用 argv 调用，不经过 shell 展开。
- `ask`、`allow`、`deny` 策略由 Dispatcher 强制执行。
- 对只读分析优先使用 Artifact 摘录；对修改任务只验证将要变更的文件。
- 累计注入模型的工具结果不超过 16,000 字符；并行结果公平共享预算，避免单个大结果挤掉其余证据；额度耗尽后关闭工具并强制收尾。

### 模型 Provider

- 支持 Anthropic Messages API。
- 支持 OpenAI Responses API。
- 可读取现有 Codex `model_provider`、`base_url` 和认证配置。
- 默认配置为 `gpt-5.6-luna`、reasoning effort `low`。
- API key 运行时从 `~/.codex/auth.json` 读取，不复制到仓库。

## 3. 主要模块

| 文件 | 职责 |
| --- | --- |
| `src/hgi/controller.py` | 输入触发、Judge、Summary、任务 generation、Commit 和取消 |
| `src/hgi/agent.py` | 最小 model/tool/result 循环与工具结果回调 |
| `src/hgi/services.py` | Judge、Summary、Explorer、Committed 服务 |
| `src/hgi/buffer.py` | Artifact 持久化、索引和相关性检索 |
| `src/hgi/tools.py` | 只读工具、写权限、命令权限和路径隔离 |
| `src/hgi/model.py` | Anthropic 与 OpenAI Responses 适配器 |
| `src/hgi/observability.py` | structlog、轮转日志、脱敏、usage 和指标聚合 |
| `src/hgi/cli.py` | prompt_toolkit 交互界面 |

## 4. 安全边界

- Explorer 没有写工具或通用 shell。
- 只读工具排除 `.env`、虚拟环境、VCS 元数据、缓存、`node_modules` 和工作区外符号链接；`.env.example` 等公开模板仍可读取。
- 所有工作区路径在解析后必须位于 workspace 内。
- Committed 写入和命令执行服从 `WritePolicy`。
- 命令执行使用 `create_subprocess_exec`，不执行 shell 字符串。
- Stop 会取消并等待 Judge、Explorer、Committed、Artifact 刷新和停顿任务收尾。
- Artifact 摘录最多 40 条、总计 24,000 字符，防止无界上下文增长。
- 日志默认不保存请求、回答、源码摘录、命令完整参数、API key 或错误正文。

## 5. 日志与成本观测

日志基于 `structlog`，通过标准库 `QueueHandler/QueueListener` 异步写入 `RotatingFileHandler`。

默认位置：

```text
<workspace>/.hgi/logs/hgi.jsonl
```

默认轮转策略：

- 每个文件 10 MB。
- 保留 5 个备份。
- 每行一个 JSON 对象。

关键字段包括：

- `session_id`、`run_id`、`generation`、`component`。
- 模型、响应 ID、调用状态和耗时。
- input、cached input、output、reasoning、total tokens。
- Judge、Summary、Explorer、Committed 分阶段 usage。
- 各模型调用和工具调用的 started/completed/cancelled/failed 计数。
- Artifact 数量、回答长度和端到端耗时。

查看运行汇总：

```bash
jq 'select(.event == "run.completed") |
  {run_id, duration_ms, usage, usage_by_component, metrics}' \
  .hgi/logs/hgi.jsonl
```

## 6. 环境与启动

项目使用现有 Conda `Python311` 解释器创建本地 venv：

```bash
cd /home/ethereal/vm2/jq/hgi
/home/ethereal/vm2/conda/anaconda3/envs/Python311/bin/python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
hgi --workspace /path/to/project
```

常用参数：

```bash
hgi \
  --provider codex \
  --model gpt-5.6-luna \
  --reasoning-effort low \
  --writes ask \
  --log-level INFO
```

## 7. 端到端评测

### 评测任务

```text
请分析 HGI 的 Speculative Buffer 如何把探索结果交给正式 Agent。
重点说明 Controller 的 artifact 选择路径，并列出关键文件；不要修改代码。
```

配置：

- 模型：`gpt-5.6-luna`。
- Reasoning effort：`low`。
- 写策略：`deny`。
- 投机组在第一句后保留 15 秒输入窗口，然后 Commit。
- 两组使用独立临时状态目录。
- 指标从 `run.completed` 结构化日志读取。

### 最新 A/B 结果

| 指标 | 投机探索 | 无投机基线 | 变化 |
| --- | ---: | ---: | ---: |
| Enter 到回答 | 46.948 s | 62.136 s | -24.4% |
| 首次输入到回答 | 61.950 s | 62.136 s | -0.3% |
| Artifact 数量 | 1 | 0 | +1 |
| 回答长度 | 2,899 字符 | 4,336 字符 | -33.1% |
| Input tokens | 174,522 | 184,891 | -5.6% |
| Cached input tokens | 23,040 | 49,664 | -53.6% |
| Output tokens | 2,081 | 2,195 | -5.2% |
| Reasoning tokens | 335 | 144 | +132.6% |
| Total tokens | 176,603 | 187,086 | -5.6% |
| 模型请求 | 11 | 9 | +22.2% |
| 工具调用 | 16 | 17 | -5.9% |

投机组分阶段 token：

| 阶段 | Total tokens |
| --- | ---: |
| Judge | 262 |
| Summary | 335 |
| Explorer | 23,847 |
| Committed | 152,159 |

投机阶段额外使用约 24,444 tokens，但让 Committed 阶段相对基线减少约 34,735 tokens，净减少 10,483 tokens。

### 价格估算

按 2026-10-01 OpenAI 文档中 `gpt-5.6-luna` 的标准单价：

- Input：$0.20 / 1M tokens。
- Cached input：$0.02 / 1M tokens。
- Output：$1.20 / 1M tokens。

计算时 cached input 从 input 中扣除后单独计价：

```text
投机探索：$0.03325
无投机基线：$0.03067
两组合计：$0.06393
```

投机组总 token 更少，但 cached input 命中也更少，因此估算金额高约 8.4%。当前请求经过自定义 `ipads` provider，实际账单仍取决于该 provider 的额度、折扣或加价。

开发期间所有真实模型测试合计粗估为 $0.17-$0.24。早期测试尚未启用 usage 日志，因此该数字是区间估算，不是账单值。

## 8. 评测解读

已经验证的收益：

- partial Artifact 可以在 Explorer 未完成时被正式任务复用。
- 正式阶段模型轮次和文件探索量通常减少。
- 用户按 Enter 后的等待时间在本轮测试中下降 24.4%。
- 15 秒用户输入时间基本覆盖了投机探索的墙钟开销。

当前代价：

- Judge、Summary 和 Explorer 增加模型请求数。
- 投机组缓存命中下降，导致金额未随总 token 同步下降。
- Committed Agent 仍会重新验证部分文件。
- 被取消的模型请求没有最终 usage 响应，日志中的 token 是可观测下界。

### 长输入与无关背景复测

2026-10-02 使用同一权限审查任务模拟了 40 秒输入：第一阶段立即给出完整意图，第二阶段持续追加不改变目标的背景信息。

| 版本 | Enter 到回答 | Total tokens | Explorer tokens | Committed 调用 |
| --- | ---: | ---: | ---: | ---: |
| 无投机基线 | 59.405 s | 108,719 | 0 | 5 |
| 优化前投机 | 50.561 s | 258,575 | 131,476 | 5 |
| 去重和预算后、过滤前 | 88.516 s | 143,114 | 16,418 | 7 |
| 加入敏感/生成目录过滤 | 55.617 s | 26,074 | 3,114 | 3 |

最终一轮答案仍覆盖 `allow/ask/deny`、路径逃逸和 shell 注入。相对基线，总 token 降低 76.0%；相对优化前投机版本降低 89.9%。最终一轮的 55.617 秒仍包含 17.5 秒提交时 Summary 等待，该阻塞调用已在测试后移除，因此表中尚未反映这项最后优化。

根因是原只读文件清单包含 `.venv`，500 项上限和工具上下文预算被依赖文件占满，产生的 Artifact 没有源码证据；Committed Agent 甚至尝试读取 `.env`。统一过滤后，Explorer 文件清单从大量环境文件缩减为 23 个真实项目文件。

### 跨请求缓存摊薄复测

同一个只读安全分析问题在同一 workspace/state 运行四轮。第一轮建立带文件哈希的 Artifact；第二轮验证缓存命中；第三轮将旧实现产生的两份重复缓存压缩为一份；第四轮代表稳定态。

| 指标 | 首轮冷缓存 | 第四轮稳定态 | 变化 |
| --- | ---: | ---: | ---: |
| Explorer 等待 | 37.604 s | 29.644 s | -21.2% |
| Enter 到回答 | 28.245 s | 23.914 s | -15.3% |
| Total tokens | 18,235 | 8,150 | -55.3% |
| Explorer tokens | 12,921 | 3,771 | -70.8% |
| Committed tokens | 4,790 | 3,806 | -20.5% |
| Explorer 模型调用 | 4 | 1 | -75.0% |
| 持久 Artifact 数量 | 1 | 1 | 不增长 |

四轮答案均覆盖 `.env`、`.venv` 和工作区外符号链接。稳定态只命中一份 Artifact，Explorer 与 Committed 各调用模型一次。结果证明缓存能够摊薄重复问题的输入和探索成本，同时硬预算仍限制最坏情况。

### 长输入摘要提交与 Committed 预算复测

2026-10-04 使用 4,518 字符请求复测完整链路：前 4,445 字符为重复背景，最后 72 字符才给出分析 `Controller → Artifact → Committed Agent` 的明确目标。两轮均保留 12 秒第二阶段投机窗口，使用独立临时状态目录和 `deny` 写策略。

| 指标 | 完整原文提交 | 摘要提交 + 工具硬预算 | 变化 |
| --- | ---: | ---: | ---: |
| Committed 请求字符 | 4,518 | 90 | -98.0% |
| Enter 到回答 | 39.191 s | 30.733 s | -21.6% |
| 首次输入到回答 | 58.469 s | 46.745 s | -20.1% |
| Committed 模型调用 | 4 | 3 | -25.0% |
| Committed tokens | 53,009 | 11,850 | -77.6% |
| 全链路可观测 tokens | 67,621 | 19,796 | -70.7% |
| 最大 Committed prompt | 86,177 字符 | 22,199 字符 | -74.2% |
| 最终答案 | 3,629 字符 | 3,376 字符 | -7.0% |

按标准单价粗估，可观测成本从约 `$0.0152` 降到约 `$0.0059`，降低约 61%。两轮都有被取消且没有最终 usage 的 Explorer 请求，因此仍是账单下界。

实现上，Commit 在现有 Summary 与请求前缀一致时只传摘要；尚未总结的最新尾部原样追加，摘要缺失或不匹配时回退完整请求。Committed 工具结果采用 16,000 字符累计硬预算，同批结果公平分配；预算耗尽后的下一轮关闭工具并强制收尾。最终轮生成 1,124 output tokens 仍耗时 22.654 秒，是当前超过 15 秒目标的主要剩余瓶颈。

## 9. 已知限制与后续工作

1. 当前数据来自单轮真实 A/B，模型路径和网络延迟存在波动。应连续运行 10-20 轮并报告 P50/P95。
2. 当前目标去重使用本地词项与技术标识符相似度，仍需用更多改写和真实意图变更样本校准误判率。
3. 当前缓存按同主题替换而非细粒度 evidence graph 合并；跨主题共享同一文件证据时仍可能重复保存。
4. 应分别统计已取消请求的 provider 账单，校准日志 usage 下界。
5. 如需跨主机集中观测，可在现有 structlog 事件之上接入 OpenTelemetry、Loki 或其他日志平台。
6. 当前轮转适合单进程 CLI；多进程共享同一日志文件时需要改为集中 sink 或支持进程锁的 handler。
7. `run_command` 的主动修改检测比较 2 MB 以下、非敏感/非生成文件的 `mtime_ns + size`；极少数保留相同元数据的原地写入会延迟到 SHA-256 懒校验时发现。HGI 之外的外部修改也依赖该懒校验。

## 10. 验证状态

```text
47 passed
No broken requirements found.
```

覆盖范围包括：

- Artifact 质量门槛、持久化、同主题替换、哈希失效、精确主动失效、后台刷新与跨会话注入。
- 路径逃逸和 Explorer 权限边界。
- `write_file` 与 `run_command` 修改检测、刷新取消，以及失败提交不触发刷新。
- Evidence 级检索、通用词过滤、Committed 证据捕获、provisional 过期，以及刷新超时/重试。
- 写入、命令权限与 argv 调用。
- 输入触发、探索、提交、取消和 partial Artifact。
- 相似目标去重、Explorer 自适应软/硬预算、上下文预算和非阻塞 Commit。
- 敏感路径、生成目录和工作区外符号链接过滤。
- Python 3.11 CLI 参数解析。
- Codex 配置与 Responses 工具协议转换。
- structlog JSONL、脱敏、轮转、上下文、usage 和 run 聚合。
