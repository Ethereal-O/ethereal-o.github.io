# HGI：输入期间投机探索的 Coding Agent

## 1. 面向用户的语义

从用户视角看，HGI 有三种交互模式。它们共享同一个特点：**我还在组织问题时，Agent 可以在后台进行只读探索；只有正式提交后，才允许进入可写的任务执行。**

### 手动模式（默认）

> 我像使用普通 Coding Agent 一样输入需求。输入期间系统可能已经在后台读代码，但不会替我发送消息，也不会擅自改文件。我按 Enter/发送 后正式开始，按 Stop/Esc 后立即停止。

Judge 只决定何时开始或取消只读探索；Commit 和 Interrupt 完全由我控制。

### 辅助模式

> 我输入时，系统除了提前探索，还会提示"需求似乎已经完整，是否发送？"或者"新输入改变了当前任务，是否暂停？"。我可以接受，也可以继续输入。

Judge 可以建议 Commit/Interrupt，但必须由我确认。

### 自动模式（可选实验功能）

> 我允许系统在高置信度下自动判断轮次结束、提交请求，或打断已经过时的任务。我仍可随时用按钮覆盖它的决定。

自动探索、自动 Commit、自动中断 Explorer、自动中断正式任务应分别配置；自动 Commit 不代表自动授予写权限。

### 无论哪种模式

- 探索结果进入投机 Buffer，默认不展示，也不自动把完整轨迹塞入上下文。
- 正式 Agent 只取得少量相关发现，优先复用它们并避免重复探索。
- Explorer 永远没有编辑权限；正式 Agent 的写操作仍受权限策略约束。
- 用户按钮优先于 Judge，安全控制不依赖模型判断。

目标不是追求字面上的"零延迟"，而是让正式提交后的 Agent 已经掌握可复用证据，更快开始有效工作。

## 2. 架构设计

```mermaid
flowchart LR
    U[用户输入 / Commit] --> C[Controller<br/>Judge + Summary]
    C -- 探索请求 + Artifact ID --> E[Explorer Loop<br/>只读工具]
    E -- 发现摘要与状态事件 --> C
    E -- 完整 Artifact --> B[(Speculative Buffer)]
    B -- 候选索引 --> C
    C -- 按 ID 读取 / 继续探索 --> B
    B -- 选中的完整 Artifact --> K[Committed Loop<br/>受控完整工具]
    C -- 正式请求 + 完整 Artifact --> K
    K -- 变更路径：立即失效 Evidence --> B
    K -- 成功返回后：后台刷新 --> E
    K -- 结果摘要与状态事件 --> C
    K --> O[用户可见输出]
```

Controller 内部流程：

```mermaid
flowchart LR
    I[字符输入 / Commit] --> T[本地触发器]
    T -- 标点或停顿 --> J[Judge]
    J -- wait --> W[继续积累用户输入]
    J -- summarize_and_wait --> S[User Summary]
    J -- explore --> S
    UC[用户 Commit] --> S
    S -- 仅合并用户输入 --> R[按摘要检索 Buffer]
    R -- ID + 探索目标 --> SE[启动 Explorer]
    R -- 完整 Artifact + 摘要意图 --> SC[启动 Committed Loop]
```

系统逐字符接收文本，但不对每个字符调用 Judge。本地触发器在输入出现句号、问号、感叹号、换行等边界字符，或用户短暂停顿时调用 Judge。这样能尽快利用已完成的句子，又避免模型调用频率过高。

Judge 的动作是 `wait / summarize_and_wait / explore / commit`；手动模式下，用户显式 Commit 可绕过 Judge。Summary 只读取尚未总结的用户输入。两个 Loop 的反馈不触发 Judge，只供后续任务组装上下文或记录运行状态。中断策略暂不纳入本阶段架构图。

### Loop 结果回流

两个 Loop 的结果需要回到系统，但不必触发或直接进入 Judge：

- **Explorer → Buffer**：返回结构化发现、文件引用、置信度和未解决问题，完整 Artifact 落盘，短索引用于后续筛选。
- **Explorer → Controller State**：记录开始、完成和失败，供去重、并发控制和 UI 展示；状态变化本身不调用 Judge。
- **Committed → Conversation/Run Log**：保存用户可见回答以及工具、修改和测试事实，供下一次正式任务按需组装上下文。
- **Summary**：仍然只消费用户输入，不总结任何 Loop 结果。

Judge 只在本地输入触发器产生候选边界时读取 `User Summary + 尚未总结的最近用户输入 + 精简运行状态`。运行状态只用于避免重复启动任务，例如"相同主题的 Explorer 已运行"，而不是由 Loop 反馈主动唤醒 Judge。为避免用户输入持续累积，Judge 可选择 `summarize_and_wait`；达到硬性长度阈值时，Runtime 也可直接触发 Summary checkpoint。

### 组件职责

- **Input Trigger / Controller State**：逐字符接收用户文本，在标点、换行或停顿处触发 Judge；同时保存两个 Loop 的状态，但状态变化不会主动触发 Judge。
- **Judge**：读取 `User Summary`、尚未总结的最近用户输入和精简运行状态，返回 `wait`、`summarize_and_wait`、`explore` 或 `commit`。Policy 根据用户模式决定执行、提示或仅记录。
- **User Summary**：只执行 `旧 User Summary + 尚未总结的用户输入 → 新 User Summary`，不处理 Explorer 结果、Committed 输出或工具事件。它在 `summarize_and_wait`、启动探索或长度 checkpoint 时按需调用。正式提交不等待新的 Summary 调用：已有摘要覆盖当前输入时只传摘要，仍有未摘要尾部时原样追加；摘要缺失或与请求不匹配时回退完整 request。
- **Explorer Loop**：独立 `messages[]`，使用 `read/glob/grep/git diff` 等只读工具；输出带文件引用的结构化 Artifact。软预算后仅在仍产生新源码证据时继续，硬预算到达后关闭工具并收尾。
- **Speculative Buffer**：同时保存短索引和完整 Artifact。只有达到质量门槛的源码证据进入长期缓存，每条 Evidence 记录文件哈希。未完成探索和成功只读 Committed Loop 中已经取得的源码摘录会合并为一小时有效的 provisional Artifact。检索过滤通用请求词，并按 query 只返回匹配路径的 Evidence，避免宽泛 Artifact 注入无关发现。`write_file` 和 `run_command` 检测到修改时立即移除受影响的 Evidence、保留其他文件证据并将摘要标记为 stale；正式任务成功后异步启动 Explorer 刷新 stale 路径。刷新成功后以原始用户目标写入新 Artifact 并替换同主题旧版本。新用户输入会取消后台刷新，外部进程修改则由读取时的 SHA-256 校验兜底。
- **Committed Loop**：独立 `messages[]`，拥有受权限控制的完整工具。提示其优先复用投机证据、避免重复搜索，并尽快输出，但不能牺牲正确性。工具结果采用 16,000 字符累计预算；同一批并行结果公平分配剩余额度，截断结果会提示改用更窄的查询。预算耗尽后关闭工具并要求使用已有证据完成回答，避免空结果循环。
- **Runtime/Policy**：实现按钮控制、权限、取消、任务 generation 和迟到结果处理。安全边界不依赖 Prompt。

Explorer 和 Committed Agent 自己产生摘要：Explorer 返回结构化发现；Committed Agent 返回用户答案，Harness 确定性记录工具、修改和测试事件，不再交给 User Summary 重复总结。

Artifact 生命周期为 `provisional → valid → stale → refreshing → valid`。provisional 只用于一小时内的近期追问；失效是同步的，保证旧证据不会进入下一次 Committed Loop；刷新是异步的，不增加当前提交的 Enter-to-answer 延迟。每次刷新调用默认限制为 30 秒，失败后延迟 3 秒重试一次。若仍失败或被取消，Artifact 保持 stale，后续 Explorer 可继续处理 unresolved 路径。

### Judge 触发时机

第一版只考虑文本输入。系统逐字观察，但仅在候选边界调用 Judge：

- 输入 `.`、`!`、`?`、中文句号/问号/感叹号、分号或换行时触发。
- 输入逗号通常不立即触发，除非随后出现 400–700 ms 停顿。
- 没有标点但停止输入约 500–800 ms 时触发。
- 显式 Commit 立即进入正式流程；手动模式无需 Judge 批准。
- 相同输入版本只判断一次，并设置最小调用间隔，避免标点与停顿重复触发。

本地规则只决定"什么时候值得问 Judge"，语义完整性和后续动作仍由 Judge 判断。

### 核心循环

两个 Agent 使用同一种最小 Loop，但上下文和工具权限不同：

```python
while True:
    response = model(messages, allowed_tools)
    if not response.tool_calls:
        return response
    results = dispatch(response.tool_calls)
    messages += [response, results]
```

### 权限与控制模式

建议默认配置：

```yaml
auto_explore: true
auto_cancel_explorer: true
commit_mode: manual        # manual | assist | auto
interrupt_mode: manual     # manual | assist | auto
judge_shadow_control: true
writes: ask
```

用户按钮始终优先于 Judge。Explorer 的 dispatcher 不注册 `edit/write` 或通用 shell；Committed Agent 的写入仍经过权限检查。

## 3. 语言与依赖

选择 Python 3.11+：适合快速实现 LLM API、`asyncio` 后台任务、CLI 和结构化数据，且与参考项目一致。

建议轻量依赖：

- 官方模型 SDK（如 `anthropic`）
- `python-dotenv`：配置
- `pydantic`：Judge、Summary、Artifact schema 校验
- `prompt_toolkit` 或 `textual`：流式输入与 CLI（按 UI 复杂度二选一）

持久化第一版使用 JSONL 与普通文件，无需向量数据库。Buffer 较小时用关键词、路径和新鲜度排序。

## 4. 示例

### 示例 A：在完整句段后提前定位代码

```
用户逐字输入："帮我看看登录后偶尔掉线的问题。"
系统：检测到句号，触发 Judge
Judge：句子已表达出可探索方向，返回 explore
Summary：将该稳定用户输入更新为当前意图
Explorer：定位 session、token rotation 和相关测试，写入 A12/A13

用户补充："主要发生在 refresh token 之后。"并按 Enter
系统：显式 Commit，使用摘要意图与尚未摘要的最新输入选择并加载 A12/A13
Committed Agent：验证已有证据后直接分析或修复，避免重复全仓搜索
```

### 示例 B：连续探索

```
第一次 Explorer 找到认证入口，将完整发现保存为 A20
用户继续补充 refresh token 线索
Controller 校验 A20 的文件哈希，将未过期证据和新探索目标交给 Explorer
Explorer 直接复用未变化证据，只搜索 unresolved 或 stale 路径
```

### 示例 C：手动控制

```
Judge 认为表达完整，shadow 模式记录 recommend_commit
系统不自动发送；用户按 Enter 后才启动 Committed Loop
用户按 Stop 时 Runtime 立即停止输出并阻止后续工具，不等待 Judge
```

### 示例 D：正式提交时传递完整 Artifact

```
Explorer 完成：发现 s01 的最小循环和 s04 的 Hook 机制
  → 完整 Artifact 写入 Buffer
  → 完成摘要和 Artifact ID 广播给 Controller

用户 Commit
  → 使用摘要意图与尚未摘要的最新输入检索 Artifact
  → Controller 根据索引选出相关 Artifact
  → 将完整 Artifact 连同精简后的正式意图一次性交给 Committed Loop
  → Committed Loop 首轮即可使用证据，无需先调用 read_artifact
```

## 5. 对 `learn-claude-code` 的参考

| 章节 | 借鉴内容 |
| --- | --- |
| `s01_agent_loop` | 最小的 model → tool → result 循环 |
| `s02_tool_use` | 工具 schema、handler registry 与统一 dispatch |
| `s03_permission` | 在 dispatcher 强制权限，而不是只写 Prompt |
| `s04_hooks` | 输入、工具前后、停止等生命周期事件 |
| `s06_subagent` | Explorer 使用独立上下文，只回传最终发现 |
| `s07_skill_loading` | Buffer 先暴露短索引，再按需读取 payload |
| `s08_context_compact` | 大输出落盘、上下文只保留摘要和引用 |
| `s11_background_tasks` | 后台探索、完成队列和安全的结果回流 |
| `s17_goal_loop` | 结构化 Judge/停止决策；后续可用于完成度检查 |

不直接复制综合 Harness；第一版组合上述最小机制，优先验证：投机探索能否降低提交后的重复搜索和任务完成时间。
