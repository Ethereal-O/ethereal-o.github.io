# Where raf stands

Measured on one machine against one drive, with fio in the same shape beside
raf at every point. What follows is what the measurements support, and the
places where they do not support a conclusion are marked as such.

**The machine.** KIOXIA EXCERIA G2 NVMe, `/dev/nvme0n1p2`, default ext4 on
the root partition, 20 cores, 31 GiB RAM, Linux 6.17, Ubuntu 24.04. It is not
idle: kubelet and a VM image live on the same filesystem and share its
journal.

**The caveat that matters more than any number here.** The drive degrades as
a session writes to it, and does not recover on its own. The same command --
one writer, 4 KiB durable appends -- read 5.8 MiB/s early in a session and
1.7 MiB/s after a terabyte had gone through. **Absolute figures on this page
are floors.** Ratios between raf and fio hold, because every one of them
comes from two runs taken back to back, in alternating order, at the same
worker count.

## In one table

Where raf sits against fio in the same shape, and against the drive, at the
worker count where each workload stops improving. `amp` is device bytes per
payload byte.

| workload | raf MiB/s | fio MiB/s | raf/fio | raf amp | device bytes, of the drive |
|---|---|---|---|---|---|
| 4 KiB random read, buffered | 462 | 945 | **0.49** | 2.00 | **99%** |
| 4 KiB random read, `directReads` | 713 | 934 | **0.76** | 1.12 | 86% |
| 1 MiB random read, buffered | 831 | 869 | 0.96 | 1.00 | 44% |
| 1 MiB random read, `directReads` | 1825 | 1912 | 0.95 | 1.00 | **96%** |
| 4 KiB sequential read, buffered | 940 | 964 | 0.97 | 1.01 | 50% |
| 4 KiB sequential read, `directReads` | 1805 | -- | -- | 1.01 | **96%** |
| 1 MiB sequential read, buffered | 916 | 945 | 0.97 | 1.00 | 48% |
| 1 MiB sequential read, `directReads` | 1711 | 1957 | 0.87 | 1.06 | **95%** |
| 4 KiB durable append | 104 | 129 | 0.80 | 3.52 | 50% |
| 4 KiB durable append, `appendBatch(64)` | 428 | -- | -- | 1.05 | 61% |
| 1 MiB durable append | 488 | 509 | 0.96 | 1.01 | 67% |

The MiB/s columns are payload. The last column is what crossed the bus --
throughput times amplification -- against the ceiling for that access
pattern, measured in the same session: 930 MiB/s for 4 KiB random, 1900 for
everything else read, 733 for streaming writes.

The two readings of the first row are the point of having both columns.
**4 KiB buffered random read delivers half of fio's payload while keeping the
drive 99% busy.** Nothing is idle and nothing is being done badly; every
record is simply dragging a second page behind it. That is what an
amplification of 2.00 means and why `directReads`, which cuts it to 1.12,
is worth 1.5x here.

(The 1.06 on the last `directReads` read row predates the window-refill fix
in `0dcfd62`; the same measurement locally reads 1.01 after it, and the
hardware number has not been retaken.)

Four sentences cover it.

**raf's only structural deficit is one 4096-byte page per record**, from a
32-byte header that pushes a 4096-byte payload across a page boundary. It is
a 100% penalty on a 4 KiB record, 0.4% on a 1 MiB one, and nothing at all on
a sequential scan, where 254 records share a window. Everywhere it does not
apply raf is within 5% of fio.

**Reads reach the drive, but only through `directReads`.** Buffered I/O caps
this machine at 733-936 MiB/s whatever the engine, queue depth, thread count
or block size, and fio does not beat that cap either. O_DIRECT reaches
1800-1900 with eight readers.

**Writes do not reach the drive, and cannot.** A durable append serialises on
ext4's journal -- 92.7% of a 16-writer run is spent in
`jbd2_log_wait_commit` -- and at 256 writers fio uses 38% of the drive's
bandwidth. Adding writers climbs towards the journal's limit, never the
drive's.

**The one lever that moves writes is asking for fewer commits.** Everything
except the payload is charged per flush: `amp(N) = C/N + 1.00` fits the batch
sweep to within 0.03. `appendBatch(64)` writes 1.05x its payload where a
record at a time writes 4.09x, and reaches 61% of the drive sustained.

## Method

Each point runs fio and raf alternately, best of N by throughput, with the
drive's ceiling measured in the same session rather than quoted from another
one. Shapes are matched: buffered raf against buffered fio, O_DIRECT raf
against O_DIRECT fio, `O_DSYNC` raf against `--sync=dsync` fio. fio gets
`--fallocate=none`, because its default reserves the file up front and raf
extends as it appends.

Two numbers are reported for every workload. Throughput, and `amp` -- device
bytes over payload bytes, from bracketing each run with `/proc/diskstats`.
The second is the one that explains the first, and it is the one that is
stable: throughput swings with the drive's mood, amplification does not.

Scripts: `bench/physical/seqscale.sh` for the sweeps, `ceiling.sh` for what
the drive can do, `appendscale.sh` for taking the append path apart.

## Reads

### 4 KiB random

40 GiB archive on a 31 GiB machine, cold, 200k operations spread over the
workers. Drive ceiling measured in the same run: 930 MiB/s, which needs 512
requests outstanding; 488 at 64.

| workers | fio buf | raf buf | ratio | fio O_DIRECT | raf O_DIRECT | ratio |
|---|---|---|---|---|---|---|
| 1 | 45.3 | 23.2 | 0.51 | 45.9 | 37.1 | 0.81 |
| 8 | 288.3 | 150.0 | 0.52 | 288.4 | 234.1 | 0.81 |
| 64 | 819.8 | 435.1 | 0.53 | 818.1 | 626.7 | 0.77 |
| 256 | 945.5 | 462.9 | 0.49 | 933.7 | 712.8 | 0.76 |
| 512 | 937.0 | 459.0 | 0.49 | 929.2 | 699.2 | 0.75 |

`amp` is 2.00 buffered and 1.12 direct, at every worker count.

Both of those are exact, not approximate. A 4096-byte payload with a 32-byte
header is 4128 bytes, and the page cache reads 4096-byte pages: 4128 never
fits in one, so two are read, and 8192/4096 is 2.00. O_DIRECT reads 512-byte
sectors instead; 4128 spans nine of them, and 4608/4096 is 1.125.

**The ratio is flat from one worker to 512.** Nothing inside raf gets worse
with concurrency; the gap is a fixed per-record cost. Buffered, the whole of
it is the 2.00. Direct, 1.12 of the 1.30 is the amplification and the rest is
the CRC and the copy, neither of which fio does at all.

Saturation: fio reaches 945 against a 930 ceiling. raf with `directReads`
plateaus at 713, which is 77% of the drive.

### 1 MiB random

Same archive, 4000 operations. The contrast with 4 KiB is the whole point of
having both.

| workers | fio buf | raf buf | ratio | fio O_DIRECT | raf O_DIRECT | ratio |
|---|---|---|---|---|---|---|
| 1 | 235.0 | 230.9 | 0.98 | 1439.4 | 1086.3 | 0.75 |
| 8 | 315.5 | 320.1 | 1.01 | 1937.0 | 1831.5 | 0.95 |
| 32 | 712.6 | 695.5 | 0.98 | 1917.5 | 1835.2 | 0.96 |
| 64 | 868.7 | 831.4 | 0.96 | 1912.2 | 1825.2 | 0.95 |

`amp` is 1.00 both ways. The same 32-byte header that costs 2.00 at 4 KiB
costs 0.4% here -- one page added to 256 -- so raf and fio are the same
program as far as the drive can tell, and the ratio says so: 0.95 to 1.01.

**raf's format penalty is a small-record penalty, and it disappears with
size.** Eight O_DIRECT readers reach 1831 MiB/s, the same as sequential: at
a megabyte there is nothing random left to pay for.

### Sequential, every worker on its own stream

Drive ceiling in the same session: 1900-1935 MiB/s under O_DIRECT. The
buffered path caps at 733-936 MiB/s on this machine *whatever* the engine,
queue depth, thread count or block size -- buffered io_uring at depth 64
reads 936, buffered psync across 32 threads reads 733. That cap is not raf's
and fio does not beat it either.

4 KiB records:

| workers | fio buf | raf buf | ratio | raf O_DIRECT |
|---|---|---|---|---|
| 1 | 458.8 | 449.6 | 0.98 | 1216.2 |
| 8 | 317.4 | 410.2 | 1.29 | 1963.0 |
| 32 | 843.1 | 750.8 | 0.89 | 1844.6 |
| 64 | 1074.8 | 863.2 | 0.80 | 1804.7 |
| 128 | 967.9 | 939.9 | 0.97 | 1814.0 |
| 256 | 963.9 | 939.5 | 0.97 | 1805.2 |

1 MiB records:

| workers | fio buf | raf buf | ratio | fio O_DIRECT | raf O_DIRECT | ratio |
|---|---|---|---|---|---|---|
| 1 | 516.1 | 313.3 | 0.61 | 1406.6 | 1092.6 | 0.78 |
| 8 | 315.0 | 329.3 | 1.05 | 1868.6 | 1833.7 | 0.98 |
| 32 | 872.2 | 822.6 | 0.94 | 1948.6 | 1764.9 | 0.91 |
| 64 | 945.1 | 916.2 | 0.97 | 1956.5 | 1710.8 | 0.87 |

`amp` is 1.00-1.01 throughout, at both sizes. The 32-byte header costs
nothing here: one window read serves 254 records at 4 KiB, so the rounding is
amortised away rather than paid per record. That is the same header that
costs 2.00 on a random read, and the difference is only whether there is
anything to amortise it over.

**Sequential read reaches the drive, with eight readers, through
`directReads`.** Buffered, raf matches fio -- 0.80 to 1.29 at 4 KiB, 0.94 to
1.05 at 1 MiB above one worker -- and neither gets past the page cache's cap.

## Writes

Every append is durable: raf opens `O_DSYNC`, fio gets `--sync=dsync`.
Spelling it `--fdatasync=1` instead changes nothing measurable (14.7, 88.4,
89.9 MiB/s against 13.3, 87.2, 83.2 at 8, 64 and 256 writers).

### 4 KiB durable append

One run, eleven worker counts, throughput and amplification at the same
point:

| writers | fio | raf | raf/fio | fio amp | raf amp | raf - fio |
|---|---|---|---|---|---|---|
| 1 | 6.0 | 5.8 | 0.97 | 7.20 | 8.13 | 0.93 |
| 4 | 11.1 | 10.7 | 0.96 | 5.56 | 6.49 | 0.93 |
| 16 | 42.3 | 40.8 | 0.96 | 4.38 | 5.28 | 0.90 |
| 32 | 43.1 | 69.2 | 1.61 | 3.99 | 4.94 | 0.95 |
| 64 | 77.6 | 111.8 | 1.44 | 3.27 | 4.09 | 0.82 |
| 256 | 100.9 | 67.7 | 0.67 | 2.75 | 3.74 | 0.99 |
| 1024 | 128.9 | 103.7 | 0.80 | 2.50 | 3.52 | 1.02 |

Read the last column, not the ratio. **raf writes fio's bytes plus one
4096-byte page per record**, at every concurrency from one writer to a
thousand. A 4096-byte payload with a 32-byte header spans two pages, and
buffered writes go out a page at a time, so the tail page of each append is
written again by the next one.

The ratio climbs from 1.13 to 1.41 not because raf gets worse but because the
bill both sides share gets smaller: journal transactions fall from 1.001 per
flush at one writer to 0.002 at 1024, as more appends batch into one commit.

### 1 MiB durable append

64 MiB per worker, and separately 256 MiB per worker to be sure the drive's
cache was not absorbing it:

| workers | fio | raf | raf/fio | amp |
|---|---|---|---|---|
| 1 | 47.4 | 156.7 | 3.31 | 1.03 |
| 8 | 847.7 | 356.9 | 0.42 | 1.02 |
| 64 | 509.0 | 488.3 | 0.96 | 1.01 |

At 256 MiB per worker: 666.7/675.5 at one writer (1.01), 437.2/418.1 at 32
(0.96), 459.2/431.6 at 64 (0.94).

**`amp` is 1.01 to 1.03.** The extra page that costs 4 KiB records between
4.11 and 8.15 is one page in 256 here. Where the 11 ms mode stays away the
two sides are within 6% of each other; the 3.31 and the 0.42 are that mode,
on raf's side in one row and fio's in the other.

For comparison, the 4 KiB amplification measured in the same script and the
same session: 8.15 at one writer, 5.61 at eight, 4.11 at 64.

### What batching does, and why

One flush per N records, 4 GiB written per point so the drive's cache cannot
absorb it:

| N | amp at 8 writers | amp at 64 writers | MiB/s at 64 writers |
|---|---|---|---|
| 1 | 5.44 | 4.09 | 19.8 |
| 2 | 3.23 | 2.55 | 39.0 |
| 4 | 2.08 | 1.77 | 75.5 |
| 8 | 1.58 | 1.38 | 167.2 |
| 16 | 1.29 | 1.19 | 250.7 |
| 32 | 1.14 | 1.10 | 260.0 |
| 64 | 1.07 | 1.05 | 427.8 |

Those fit `amp(N) = C/N + 1.00` to within 0.03 everywhere, with C = 4.43 at
eight writers and 3.09 at 64.

That is the whole story of a durable append in one line. **Everything except
the payload is charged per flush, and batching divides it by the batch size.**
The constant falls with worker count for the same reason the ratio above
climbs -- more flushes share a journal commit. The `1.00` is the payload
itself, and `appendBatch(64)` gets within 5% of writing nothing else.

It also disposes of raf's extra page: that page is part of the per-flush
cost, so at N=64 raf writes 1.05x its payload against fio's irreducible 1.00.

### Why neither side saturates the drive

At 256 writers fio moves 100.9 MiB/s of payload at 2.75x, which is 277 MiB/s
across the bus against a streaming ceiling of 733 -- **38%**. The drive is
not the limit. Sampling `/proc/<pid>/task/*/wchan` through a 16-writer run
says what is:

```
  92.70%  jbd2_log_wait_commit
   5.99%  futex_do_wait
   1.27%  folio_wait_bit_common
```

**Durable appends serialise on ext4's journal.** raf asks for no more journal
work than fio does -- the transaction counts are identical at every worker
count -- so this is the cost of the contract, not of the format.

Adding writers climbs towards the journal's throughput, never the drive's.
`appendBatch(64)` at 64 writers reaches 427.8 MiB/s of payload at 1.05x, or
449 MiB/s across the bus: **61% of the drive, sustained.** Asking for fewer
commits is the only thing that moves this.

### Things that do not help

- **A deeper queue.** One thread with 64 `O_DSYNC` writes outstanding through
  io_uring retires 1363 appends a second. Sixty-four files at depth one
  retire 4155; file count is what moves it, not depth. Even the best io_uring
  shape measured, 64 files at depth 4, retires 7634 against 23398 for 64
  plain synchronous threads. **An asynchronous append API would not help.**
- **Preallocation** (`Options::preallocateBytes`). It removes the journal
  work almost entirely -- 0.001 to 0.003 transactions per flush against 0.008
  to 0.250 -- and is the only variant whose amplification does not fall with
  concurrency, flat at 4.05 to 4.11. It spends more on zeros than it saves.
  Throughput is a quarter of raf's at 64 and 256 writers. **Leave it off.**
- **Removing the frontier write.** `RAF_PUBLISH_FRONTIER=0` is within
  measurement noise of the default at every worker count tried.

## What to turn on

| | setting | worth |
|---|---|---|
| sequential read | `Options::directReads` | 400 -> 1960 MiB/s at eight readers |
| 4 KiB random read | `Options::directReads` | `amp` 2.00 -> 1.12, 1.4 to 1.6x throughput |
| 1 MiB random read | `Options::directReads` | 320 -> 1831 MiB/s at eight readers |
| 4 KiB durable append | `appendBatch` | `amp` 4.09 -> 1.05, 20 -> 428 MiB/s at 64 writers |
| 1 MiB durable append | nothing | already 1.01x the payload and 0.96 of fio |

`directReads` is off by default for one reason: it has no cache hits. Over an
archive that fits in RAM the buffered path read 632 MiB/s against direct's
535, with 82% of its bytes never reaching the drive. Turn it on when the
archive is much larger than memory. Writers are unaffected either way.

## Open

- **An 11 ms mode.** At some worker counts a durable append's p50 jumps from
  ~1.4 ms to 8.7-11.5 ms and stays there for the run. raf lands in it more
  often than fio, but fio lands in it too (8737 us at four writers). Three
  suspects are eliminated at the magnitude where it appears: measurement
  order, page alignment, and the frontier write. Journal transaction counts
  are identical to fio's throughout. It did not appear below 128 writers in
  the cleanest run, and it is what makes raf/fio swing between 0.18 and 1.04
  in the runs where it does.
- **Why the drive degrades across a session and does not recover.** Observed
  repeatedly; never diagnosed. Settling either of these needs a drive that
  has been left alone, or trimmed, first.
- **The residual on sequential amplification.** Iteration reads 1.02 bytes
  per payload byte at 4 KiB where the arithmetic allows 1.008. Small, and not
  accounted for.
