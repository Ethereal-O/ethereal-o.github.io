# What the suite tests, and what each test is for

There are two. `raf_core_test` is 24 tests in one file, under two seconds,
holding the properties raf would be broken without --
`tests/core/README.md` says what it leaves out and shows which deliberate
breakages it does and does not catch. `raf_test`, described below, is the
whole thing: 164 tests, and the one to run before shipping.

164 tests in 14 files, one binary (`raf_test`) -- 173 when the io_uring
backend is built in, because the IO-layer tests run once per backend. Every
one of them is deterministic: payloads are a pure function of `(writer, sequence, size)` and
every rendezvous between threads or processes is a `std::latch` or a pipe, so
a failure reproduces. Nothing sleeps and nothing is random.

```sh
cmake -B build -DRAF_BUILD_TESTS=ON && cmake --build build -j
./build/raf_test                        # all of it, ~20 s
./build/raf_test --gtest_filter='DirectRead.*'
RAF_TEST_LOG=error ./build/raf_test     # damage reports are muted by default
RAF_STRESS_SCALE=8 ./build/raf_test     # longer soak

# the io_uring backend, against a liburing in a local prefix
PKG_CONFIG_PATH=/opt/liburing/lib/pkgconfig \
  cmake -B build-uring -DRAF_BUILD_TESTS=ON -DRAF_URING=ON && \
  cmake --build build-uring -j && ./build-uring/raf_test
```

## The fourteen files

| file | layer under test | n |
|---|---|---|
| `test_api.cpp` | `include/raf/raf.h` — the public contract | 21 |
| `test_iteration.cpp` | `RecordReader::readNext` ordering and visibility | 11 |
| `test_boundary.cpp` | sizes and limits at both ends | 23 |
| `test_errors.cpp` | refused opens, failed writes, damage on disk | 10 |
| `test_faults.cpp` | injected failures, through `tests/fault_backend.h` | 7 |
| `test_concurrency.cpp` | threads | 9 |
| `test_multiprocess.cpp` | processes, and `flock` between them | 5 |
| `test_recovery.cpp` | what survives a process that dies | 9 |
| `test_stress.cpp` | the same properties, run wide | 5 |
| `test_segment.cpp` | `src/store/segment.cpp` — format and scan | 25 |
| `test_direct.cpp` | the O_DIRECT read path and `ReadWindow` | 13 |
| `test_format.cpp` | `src/store/format.h` — layout and checksums | 8 |
| `test_crc32c.cpp` | `src/common/crc32c.cpp` | 9 |
| `test_backend.cpp` | `src/io/posix_backend.cpp`, `uring_backend.cpp` | 9 × backends |

---

## `test_api.cpp` — the public contract

What the calls return, what they promise, and what they do when used out of
order. Against `RecordWriter` / `RecordReader` in `include/raf/raf.h`.

| test | function | what it pins |
|---|---|---|
| `AWriterCreatesTheArchive` | `RecordWriter::RecordWriter` | constructing creates the directory and one segment |
| `AppendReturnsAnIndexThatReadsBack` | `append` → `read` | the returned index resolves to the bytes appended |
| `AppendBatchReturnsOneIndexPerValue` | `appendBatch` | one index out per value in, in order |
| `AnEmptyBatchDoesNothing` | `appendBatch` | an empty vector is not an error |
| `RecordsAreOnDiskBeforeAppendReturns` | `append`, `Options::sync` | the durability promise: the bytes are readable from a separate reader the instant `append` returns |
| `ReadNextWalksTheArchiveInOrder` | `readNext` | iteration yields append order |
| `ReadNextEndsWithNullopt` | `readNext` | end of archive is `nullopt`, not an error |
| `CurrentIndexNamesTheRecordReadNextReturned` | `currentIndex` | the index names the record just handed out, not the next one |
| `RewindStartsTheWalkOver` | `rewind` | |
| `PayloadsAreOpaqueBytes` | `append` | embedded NULs and arbitrary bytes survive |
| `WritingAfterCloseIsAProgrammingError` | `close`, `append` | misuse throws rather than corrupting |
| `ReadingAfterCloseIsAProgrammingError` | `close`, `read` | |
| `ClosingTwiceIsAllowed` | `close` | idempotent |
| `ClosingAWriterReleasesItsSegment` | `close` → `Segment::unlock` | the next writer can take it |
| `DestroyingAWriterReleasesItsSegment` | `~RecordWriter` | the same without an explicit close |
| `WritersDoNotShareASegment` | `Archive::acquireForWrite` | |
| `OpeningAnArchiveThatIsNotThereFails` | `RecordReader::RecordReader` | `Archive::requireExists` |
| `AnArchiveWithNoRecordsReadsAsEmpty` | `readNext` | |
| `AWriterCanReopenAnArchiveItAlreadyWrote` | `RecordWriter::RecordWriter` | reopen appends rather than truncates |
| `ReadersAndWritersMoveWithoutLosingTheirArchive` | move ctor / move assign | |
| `StringViewOverloadsBehaveLikeTheStringOnes` | `append(std::string_view)` | |

## `test_iteration.cpp` — ordering and visibility

Two promises: records already complete when a reader opened come out in one
order, the same for every reader; records appended afterwards keep the order
of the writer that wrote them, with no order defined between writers.
Against `RecordReader::readNext` / `rewind` in `src/api/reader.cpp`.

| test | what it pins |
|---|---|
| `OneWriterComesBackInAppendOrder` | the single-writer case, exactly |
| `ReadersAgreeOnWhatWasThereWhenTheyOpened` | two readers over the same archive produce the same prefix |
| `TheOrderOfWhatWasAlreadyThereDoesNotDependOnWhenYouRead` | opening later does not reorder the past |
| `ARecordAppendedAfterTheReaderCaughtUpBecomesVisible` | tailing a live writer |
| `AWriterThatStartedAfterTheReaderBecomesVisible` | a segment created after the reader opened is picked up |
| `ARecordStillBeingWrittenDoesNotHideAnotherSegmentsRecords` | an unfinished record stalls its own cursor, not the walk — the difference between "nothing more for now" and "nothing more until that writer finishes" |
| `RandomReadsAgreeWithTheWalk` | `read(index)` and `readNext` return the same bytes |
| `RewindReplaysTheSameRecords` | |
| `RewindPicksUpWhatWasWrittenSinceTheReaderOpened` | rewind re-scans rather than replaying a snapshot |
| `EmptyRecordsTakePartInTheWalk` | a zero-length record is a record, not an end marker |
| `SegmentRolloverKeepsTheWalkInOrder` | order holds across a segment boundary |

## `test_boundary.cpp` — the edges

Empty and maximum records, batch and segment boundaries, and lengths that
have to be turned away before anything is reserved or written.

| test | function | what it pins |
|---|---|---|
| `PreallocationChangesNothingAReaderCanSee` | `Segment::configurePreallocation` | preallocation moves zeros around, never what a reader sees |
| `APreallocatedSegmentReopensAtTheRightPlace` | `Segment::recover` | the trailing zeros are not mistaken for records |
| `EmptyRecordsRoundTrip` | `append("")` | |
| `RecordSizesFromOneByteUpwards` | `append` | every small size, not a sample of them |
| `TheLargestAllowedRecordRoundTrips` | `kMaxRecordSize` | |
| `ARecordOverTheLimitIsRefusedBeforeAnythingIsWritten` | `append` | rejection leaves the file untouched |
| `MaxRecordBytesRaisesWhatAppendWillTake` | `Options::maxRecordBytes` | and a reader told nothing about it still returns the record: the limit travels in the segment header |
| `MaxRecordBytesLowersItToo` | `Options::maxRecordBytes` | |
| `MaxRecordBytesIsCheckedWhenTheWriterOpens` | `RecordWriter::RecordWriter` | zero means the default; over `kRecordSizeCeiling` throws rather than silently clamping |
| `ASegmentWithNoLimitInItsHeaderUsesTheDefault` | `format::recordLimit` | a segment written before the field existed still reads |
| `AnOversizedValueRejectsTheWholeBatch` | `appendBatch` | all-or-nothing |
| `BatchesSpanningTheWriteChunkBoundary` | `Segment::appendRecords` | the iovec chunking loop |
| `WritersRollOverToANewSegment` | `Archive::acquireForWrite` | |
| `ABatchThatOutgrowsASegmentIsSplitAcrossSegments` | `appendBatch` | a batch is not required to fit one segment |
| `ARecordLargerThanTheSegmentLimitGoesIntoAFreshSegment` | | a record always has somewhere to go |
| `ASegmentLimitWithNoRoomForRecordsIsRejected` | `Options::maxSegmentBytes` | |
| `ASegmentLimitBeyondWhatAnIndexCanAddressIsClamped` | `format::makeIndex` | the limit is clamped to what 64 bits of index can name |
| `TheFitCheckCannotWrapHoweverLargeTheLimitIs` | `src/api/writer.cpp:82` | `offset + used + span` is unsigned; a wrap would make an over-limit batch look like it fits. Every term is bounded, and this is the bound |
| `AWholeBatchAgainstTheClampedMaximumStillResolves` | `appendBatch` | the same from the behavioural end: a wrap would put records past the cap and their indexes would not resolve |
| `ALengthThatCouldOverflowASpanIsRefusedBeforeAnythingIsWritten` | `format::recordSpan` | the refusal happens before anything is reserved |
| `IndexesThatNameNothingReadAsEmpty` | `read(index)` | a plausible but unused index is `nullopt`, not damage |
| `NegativeIndexesAreAProgrammingError` | `read(index)` | throws |
| `RecordsRightAtTheSegmentLimitFit` | | off-by-one at the segment edge |

## `test_errors.cpp` — things going wrong

The property throughout: a failure never lets a broken record pass for a
complete one, and never leaves the writer wedged.

| test | what it pins |
|---|---|
| `AnArchiveUnderAMissingDirectoryFails` | open refuses rather than creating a tree |
| `AnArchivePathThatIsAFileFails` | |
| `ADirectoryWeCannotWriteToFails` | permission failure surfaces as `std::system_error` |
| `AWriteThatRunsOutOfRoomFailsCleanly` | `RLIMIT_FSIZE` mid-write: the writer stays usable, the half-written record is not returned |
| `ADamagedPayloadIsNeverReturned` | `Segment::readPayload` rejects on the payload CRC |
| `ADamagedRecordHeaderStopsIterationRatherThanGuessing` | `format::metaIsValid` — no resynchronisation heuristics |
| `DamageInOneSegmentDoesNotStopTheOthers` | one bad file does not cost the archive |
| `ASegmentWithAnUnreadableHeaderIsSkipped` | `Segment::verifyHeader` |
| `AnEmptyFileWithASegmentNameIsAdoptedRatherThanRejected` | a zero-length segment is what a crash between create and header leaves |
| `DamageIsReportedThroughTheLoggerRatherThanSilently` | `raf::logger()` gets the report |

## `test_faults.cpp` — injected failures

Everything raf does to a file goes through `IoBackend`, so that is where a
failure can be injected the filesystem will not produce on demand.
`tests/fault_backend.h` holds a `ForwardingBackend` that passes everything
through and a `FaultBackend` with four knobs: how many writes to let past
before bending one, how many bytes of the bent write land before it reports
EIO, an offset to fail writes at, and whether `fsync` fails. It also records
`syncDirectory` calls, which is the only way to assert on one — the
durability of a new segment's directory entry leaves no trace in the archive.

These drive the store layer directly, since that is the level a backend is
injectable at.

| test | function | what it pins |
|---|---|---|
| `AWriteThatFailsHalfwayLeavesNoPieceOfARecord` | `Segment::appendRecords` | the rollback in the catch block: a header with no payload behind it is cut off, not left for recovery |
| `AWriterCarriesOnAfterAFailedWrite` | `Segment::appendRecords` | not wedged — the same segment takes records again once the failure clears |
| `AFailedAppendHandsOutNothingAReaderWillHonour` | `format::makeIndex` | the offset the failed record would have had goes to the next one |
| `RecoveryDropsAPartialRecordTheRollbackCouldNotRemove` | `Segment::recover` | the rollback is best effort and can itself fail, so a scan has to reach the same verdict alone |
| `ASegmentWhoseHeaderCannotBeSyncedIsNotHandedBack` | `Segment::initialize` | a failed header sync must not yield a usable segment; the alternative is a file every later scan special-cases |
| `ANewSegmentSyncsTheDirectoryItWasCreatedIn` | `Archive::acquireForWrite` | `src/store/archive.cpp:55` — a crash before it would leave records with no name. Reopening an existing segment syncs nothing |
| `AnAppendSurvivesAFrontierThatCannotBeWritten` | `Segment::publishFrontier` | the frontier is a diagnostic: losing it costs a reader a worse answer, never a wrong one, and it is given up on once rather than retried per append |

## `test_concurrency.cpp` — threads

| test | what it pins |
|---|---|
| `AWriterPerThread` | N writers, N segments, every record lands once |
| `OneWriterSharedByManyThreads` | one `RecordWriter` is safe to share |
| `BatchesFromManyThreadsStayContiguous` | a batch is never interleaved with another thread's |
| `RandomReadsFromManyThreadsShareOneReader` | `RecordReader::read` is reentrant |
| `ReadNextFromManyThreadsHandsOutEachRecordOnce` | `readNext` is a queue, not a broadcast |
| `AReaderSeesEachRoundOfWritesAsItLands` | visibility under load, round by round |
| `ReadersAndWritersRunTogether` | the two paths do not interfere |
| `WritersOpenedAndClosedRepeatedly` | segment acquire/release under churn |
| `DurableAppendsFromManyThreads` | `Options::sync` holds with contention |

## `test_multiprocess.cpp` — processes

A writer's claim on a segment is an `flock`, which conflicts between open
file descriptions, so the mechanism that separates two threads separates two
processes — and survives one that dies without cleaning up. Parent and child
meet at pipe-backed gates, so the event order is fixed.

| test | what it pins |
|---|---|
| `ProcessesNeverShareASegment` | `IoBackend::tryLockExclusive` across a fork |
| `RecordsFromSeveralProcessesAllLand` | |
| `ASegmentHeldByADeadProcessIsTakenOver` | the kernel drops the lock; the next writer recovers and continues the file |
| `AReaderSeesAnotherProcessesWrites` | |
| `InterleavedProcessesKeepTheirOwnOrder` | per-writer order holds across processes |

## `test_recovery.cpp` — crash recovery

A dying process is a fork whose child leaves through `_exit` or `SIGKILL`, so
no destructor runs and nothing is closed. The contract each time: every
record whose `append` returned is still there, no partial record is ever
mistaken for a complete one, and the next writer resumes exactly where the
last stopped. Against `Segment::recover` in `src/store/segment.cpp`.

| test | what it pins |
|---|---|
| `RecordsSurviveAWriterThatNeverClosed` | |
| `RecordsSurviveSigkill` | |
| `IndexesHandedOutBeforeACrashStillResolve` | an index is durable the moment it is returned |
| `TheNextWriterTakesOverTheCrashedWritersSegment` | |
| `RecordsWrittenAfterRecoveryDoNotOverwriteTheOldOnes` | recovery sets the append offset, not zero |
| `CrashingAndRecoveringRepeatedlyKeepsEverything` | recovery is idempotent over many rounds |
| `AFileCutAtAnyPointRecoversToARecordBoundary` | truncation at *every* byte offset, not a sample |
| `ConcurrentWritersAllRecover` | |
| `RecoveryDoesNotDisturbAnUndamagedArchive` | the no-op case stays a no-op |

## `test_stress.cpp` — scale

The same correctness checks run wide enough to shake out what only appears
under load. `RAF_STRESS_SCALE` multiplies the sizes.

| test | what it pins |
|---|---|
| `ManyWritersAndReadersAtOnce` | |
| `LargeRecordsUnderLoad` | the sizes the design targets (1 MiB) |
| `SegmentChurn` | many rollovers in one run |
| `ReopeningAnArchiveManyTimes` | recover-and-append repeated |
| `RandomReadsAcrossManySegments` | `Segment` cache behaviour in `src/api/reader.cpp` |

## `test_segment.cpp` — the store layer

The segment file format, and what a scan makes of a file a crash or a bad
sector got to first. The largest file in the suite; most of the damage
semantics live here.

**Layout and append** — `Segment::initialize`, `appendRecords`,
`Archive::segmentPath`:

| test | what it pins |
|---|---|
| `ANewSegmentStartsWithAValidHeader` | |
| `SegmentNamesRoundTrip` | `Archive::segmentPath` ↔ id |
| `RecordsLandBackToBackAfterTheHeader` | byte-exact layout, no padding |
| `AppendTimestampsNeverGoBackwards` | `RecordMeta::timestamp_ns` is monotonic |
| `SequenceNumbersContinueAfterReopen` | |

**Scan** — `Segment::recover`, returning `ScanResult`:

| test | what it pins |
|---|---|
| `ScanFindsEveryRecordAfterAReopen` | |
| `ScanDropsATornTail` | trailing non-records belong to an append that never returned, so dropping them loses nothing promised |
| `ScanDropsARecordWhosePayloadNeverLanded` | a header without its payload |
| `ScanStepsOverADamagedRecordAndKeepsTheRestOfTheFile` | a bad payload with a good record behind it is damage, not a tail |
| `ScanCountsWhatItFound` | `ScanResult` counters |

**The frontier** — `Segment::publishFrontier` / `metaFd`. The frontier is the
writer's published high-water mark, and it is what lets a scan tell damage
from an unfinished write:

| test | what it pins |
|---|---|
| `ABadHeaderBelowTheFrontierIsDamage` | the writer acknowledged it, so breaking it is loss |
| `ABadHeaderAboveTheFrontierLooksLikeAnUnfinishedWrite` | past the frontier nothing was acknowledged |
| `AnImpossibleFrontierIsIgnored` | it has no checksum, so a value that cannot be true is not believed — believing an overstated one would report every unwritten byte as damage |
| `FileLengthDoesNotDecideDamage` | the rule the frontier replaced: file length broke on preallocated files and on a dead writer's file |

**Reading** — `Segment::fetchMeta`, `readPayload`:

| test | what it pins |
|---|---|
| `ReadingAPayloadPicksUpTheNextHeaderInTheSameCall` | iteration costs one read per record, not two |
| `ReadingADamagedPayloadIsReportedSeparately` | `ReadStatus` distinguishes damage from end |
| `APayloadCutShortAboveTheFrontierIsTheTail` | |

**Speculation** — a random read guesses the record length so it can fetch
header and payload in one call. Every case must return the right bytes
whatever the guess was:

| test | what it pins |
|---|---|
| `SpeculationLearnsTheRecordSizeAndStaysCorrect` | the guess adapts to the last span seen |
| `SpeculationSurvivesRecordsOfEveryOtherSize` | alternating sizes defeat the guess every time |
| `SpeculationGivesUpOnRecordsThatAreTooLarge` | past a ceiling it stops guessing rather than allocating large |
| `SpeculationReadingPastTheEndOfTheFileIsFine` | a short read at the last record is the end of the file, not an error |
| `SpeculationStillChecksThePayload` | the CRC is over the bytes that actually came back |

**Archive** — `Archive::acquireForWrite`, `openForRead`:

| test | what it pins |
|---|---|
| `AFileThatIsNotASegmentIsIgnored` | |
| `WritersTakeSeparateSegments` | |
| `AFullSegmentIsLeftAlone` | |

## `test_direct.cpp` — the O_DIRECT read path and the window

`O_DIRECT` is what `Options::directReads` asks for and it is on by default:
no page cache, and three alignment rules — offset, length and buffer address
all multiples of the device's logical block. Everything the buffered reader
promises has to survive that, which is why the buffered side is still here
to compare against.

Because the default is `O_DIRECT`, every test in the suite needs a
filesystem that can do it. `TempArchive` picks one, falling back from `/tmp`
to the working directory, since tmpfs refuses `O_DIRECT` outright.

**Equivalence** — `Segment::readPayload` with `direct_` set, via
`src/store/read_window.cpp`:

| test | what it pins |
|---|---|
| `IteratesEveryRecordInOrder` | record sizes that are a multiple of nothing, so every record starts and ends mid-sector |
| `AgreesWithTheBufferedReader` | record for record, both paths |
| `IterationAndRandomLookupAgree` | the two window paths — iteration slides one, a lookup speculates into a fresh one |
| `HandlesARecordLargerThanTheWindow` | `ReadWindow::reserve` — the oversized path |
| `RandomLookupReturnsTheSameRecords` | `Segment::readAligned`, the no-window path, several threads on one segment |
| `SeesRecordsAppendedAfterItCaughtUp` | tailing a live writer through `O_DIRECT` |
| `ReportsADamagedPayloadLikeTheBufferedReader` | damage reads as damage, not as end of data |

**Bytes moved** — these are the only tests in the suite that count what the
`IoBackend` was asked for rather than what came back, through a
`CountingBackend`. They exist because the window can be badly wrong in a way
nothing above it can observe: it used to fill its whole buffer on every
refill, so a 4 KiB random lookup against a 64 KiB buffer moved sixteen times
the bytes it needed. The benchmark saw an amplification of 16.12; the suite
saw nothing at all.

| test | function | what it pins |
|---|---|---|
| `FetchesWhatWasAskedForWhenThereIsNoReadahead` | `ReadWindow::read`, `readahead_ == 0` | asks for what it needs, rounded to a sector, and no more |
| `DoesNotKeepReadingABufferItHadToGrow` | `ReadWindow::reserve` | one oversized record must not make every small one after it expensive |
| `ARandomLookupReadsAboutOneRecord` | `Segment::readAligned` | the 16.12 regression, as a test |
| `FetchesAheadWhenToldTo` | `ReadWindow::read`, `fetch_at_least` | readahead still happens when iteration asks for it |
| `IterationDoesNotRefetchAtAnyRecordSize` | `Segment::windowFetch` | the second regression: refills used to start mid-record, so each one inherited the offset and 256 KiB records cost 1.34x |
| `AppendsSurviveAndStopAskingWhenDescriptorsRunOut` | `Segment::disableFrontier` | EMFILE on the frontier descriptor disables it permanently instead of retrying per append |

## `test_format.cpp` — layout and checksums

Against `src/store/format.h`. Two CRCs per record: one over the header minus
its own field, one over the payload behind it.

| test | what it pins |
|---|---|
| `HeaderAndMetaAreFixedSize` | `sizeof(SegmentHeader) == 64`, `sizeof(RecordMeta) == 32`, `kHeaderSize == 4096` so the frontier has a page to itself |
| `MetaChecksumCoversEverythingExceptItself` | `format::computeMetaCrc` |
| `MetaChecksumNoticesEveryOtherField` | every field, one at a time |
| `MetaValidationRejectsGarbage` | `format::metaIsValid` |
| `SegmentHeaderChecksumCoversEverythingExceptItself` | `format::headerIsValid` |
| `IndexPacksSegmentAndOffset` | `format::makeIndex`, `segmentOf`, `offsetOf` |
| `NegativeIndexesAreRejected` | |
| `RecordSpanIncludesTheHeader` | `kMetaSize` is part of the span an index skips |

## `test_crc32c.cpp` — the checksum

Against `src/common/crc32c.cpp`. The fast path folds three interleaved
checksums back together with precomputed GF(2) shifts — arithmetic that can
be subtly wrong while still looking plausible — so every test compares
against a bit-at-a-time reference implementation in the test file that shares
no table and no code path with it.

| test | what it pins |
|---|---|
| `MatchesTheCastagnoliCheckValues` | the published check values |
| `CoversEveryByteValue` | |
| `SplittingTheInputDoesNotChangeTheResult` | incremental use |
| `MatchesTheDefinitionAtEveryLength` | against the reference, every length |
| `SplittingAcrossTheInterleavedBlockIsExact` | the three-way fold at its seam |
| `DetectsBitFlipsAnywhereInALargeBuffer` | |
| `NoticesSlicesSwappedAround` | a fold that misplaces a slice |
| `DetectsSingleBitFlips` | |
| `HandlesLengthsAroundTheWordLoop` | the tail of the 8-byte loop |

## `test_backend.cpp` — the IO layer

Value-parameterised over every backend built in: POSIX always, io_uring when
`RAF_URING` is on. The layers above name no POSIX API, so a backend is
interchangeable or it is nothing, and both have to pass the same nine tests.
A backend that is compiled in but unavailable on the running kernel —
io_uring is restricted or absent on plenty of them — is found out with one
real write in `SetUp` and skipped rather than failed.

| test | function | what it pins |
|---|---|---|
| `WritesAndReadsBack` | `writeAll`, `readSome` | |
| `ScattersAcrossMoreIovecsThanTheKernelTakesAtOnce` | `writeAll` | the `IOV_MAX` chunking loop |
| `ReadPastTheEndReturnsWhatIsThere` | `readSome` | a short read is not an error |
| `TruncateAndSizeAgree` | `truncate` | |
| `ExclusiveLockConflictsWithinOneProcess` | `tryLockExclusive` | `flock` conflicts between descriptions, not processes |
| `OpenReportsFailures` | `open`, `tryOpen` | `errno` surfaces |
| `DirectoryOperations` | `makeDirectory`, `directoryExists`, `listDirectory`, `syncDirectory` | |
| `SyncWritesSurviveWithoutAnExplicitFlush` | `OpenFlags::sync` | |
| `AWriteThatCannotFinishFailsWithItsPrefixOnDisk` | `writeAll` | a genuine short `pwritev` via `RLIMIT_FSIZE`: the retry loop makes progress, then surfaces EFBIG instead of spinning or returning quietly |

---

## What the suite does not test

Deliberately, and measured elsewhere:

- **Performance.** No test asserts a rate. The two byte-counting tests in
  `test_direct.cpp` are the exception that proves it — they assert *bytes
  requested*, which is deterministic, not time. Throughput lives in
  `bench/` and the numbers in `docs/performance.md`.
- **Resource use.** Now reported by the benchmarks rather than asserted:
  `raf_bench` prints a CPU-seconds-per-GiB column and a peak-RSS line,
  `raf_matrix` carries both on the end of its report line.
- **Real power loss.** `SIGKILL` and truncation stand in for it. They cover
  a process dying, not a drive that lies about its cache.
- **Filesystems that cannot do `O_DIRECT`.** `Options::directReads` can be
  turned off for them, but the suite exercises the default and so needs a
  root that supports it.

## Against the design doc

`docs/stage3.md` §6 lists eight kinds of test. Where each one landed:

| stage3 §6 | here |
|---|---|
| API 契约、持久化契约 | `test_api.cpp`, with `RecordsAreOnDiskBeforeAppendReturns` for the returning-append-is-durable promise and `ANewSegmentSyncsTheDirectoryItWasCreatedIn` for the directory entry |
| 预期错误与故障注入 | `test_errors.cpp` for the failures a real filesystem produces, `test_faults.cpp` for the ones it will not |
| 边界条件与长度溢出 | `test_boundary.cpp`, including the three overflow tests |
| 正确性对照测试 | `test_support.h`'s `PayloadId` — every record carries its writer, sequence and a checksum |
| 崩溃恢复与并发崩溃恢复 | `test_recovery.cpp` |
| 并发正确性与反复开关 | `test_concurrency.cpp`, `test_multiprocess.cpp` |
| 性能测试（吞吐、恢复耗时、资源占用） | `bench/`; recovery scan time and the CPU/RSS columns are both in `raf_bench` |
| 压力测试 | `test_stress.cpp`, and `bench/physical/vsfio.sh` from 1 to 256 workers |

Two places where the implementation deliberately differs from what §6 asks
for, both because the result is stronger:

**Seeds.** §6 suggests re-running the concurrency and crash tests with
different random seeds and keeping the seed of a failure to reproduce it.
There are no seeds here. Payloads are a pure function of
`(writer, sequence, size)` and every rendezvous is a `std::latch`, so there
is nothing to keep — a failure reproduces because the inputs never varied.
What varies between runs is the interleaving, and no assertion depends on it.

**Crash points.** §6 asks for the process to be killed at five named stages:
after reserving, after writing data, after writing metadata, after syncing,
and after acknowledging. `AFileCutAtAnyPointRecoversToARecordBoundary`
truncates at *every byte offset* instead. The on-disk states those five
stages produce are a subset of what it covers.

## The benchmarks, for contrast

Not part of `raf_test`; these are scripts that need a machine and a drive.
Each answers a question rather than producing a score.

| script | the question |
|---|---|
| `bench/physical/vsfio.sh` | how close is raf to fio in the same shape, 1→256 workers, six workloads |
| `bench/physical/seqscale.sh` | does that still hold once the device is saturated — every worker on its own stream, four matched sides per point |
| `bench/physical/ceiling.sh` | what can this drive actually do, and how much of it can a synchronous buffered reader reach |
| `bench/physical/appendscale.sh` | why durable append stops scaling at sixteen writers; takes the append path apart variant by variant |
| `bench/physical/appendcost.sh` | where the microseconds in one durable append go |
| `bench/physical/sustained.sh` | where the drive's SLC cache runs out, and whether batching survives the cliff |
| `bench/physical/diagnose.sh` | is this drive healthy enough to trust a run on it |
| `bench/physical/run.sh` | all of the above into one results file |
| `bench/raf_matrix.cpp` | the harness: `write`, `scan`, `read`, `seqread`, `odread`, `odrand`, with device-level amplification from `/proc/diskstats` |
| `bench/bench_raf.cpp` | the standalone benchmark, no fio and no root needed |

`bench/physical/README.md` records which of its questions are answered and
which are still open; `docs/performance.md` is where the answers are.
