# Measuring raf on real hardware

Everything in the repo so far was measured inside a QEMU VM whose disk
presents as `QEMU HARDDISK` over emulated SCSI, with `rotational=1` and a
write-back cache. A 4 KiB durable append costs about 1.4 ms there; on an NVMe
it is 10-20 us. That gap does not merely scale the numbers down, it changes
which conclusions hold:

| 4 KiB durable append, 1 writer | posix MiB/s | io_uring / posix |
|---|---|---|
| tmpfs (no block layer) | 2709 | **0.19** |
| `null_blk`, no device latency | 133 | 0.86 |
| `null_blk`, 15 us injected | 49 | 0.90 |
| this VM's QEMU SCSI disk | 3.0 | **1.13** |

io_uring's `iou-wrk` handoff is a fixed ~7.5 us. It is 0.5% of a 1.4 ms append
and invisible; it is a third of a 20 us one. **The VM says io_uring is free
because the storage is slow.** These scripts exist to find out what real
storage says.

## What is still open

1. **Does io_uring's handoff matter on a real NVMe?** Predicted yes, roughly
   0.85-0.95 on small durable appends. Never measured on hardware.
2. ~~**What does the 2.00x read amplification cost?**~~ **Answered: half the
   throughput, and O_DIRECT gets most of it back.** Random reads, 40 GiB
   archive on a 31 GiB machine, cold:

   | workers | fio | raf | raf-od | raf/fio | od/fio | amp | od amp |
   |---|---|---|---|---|---|---|---|
   | 1 | 44.8 | 23.7 | 38.3 | 0.53 | 0.85 | 2.00 | 1.12 |
   | 8 | 280.6 | 148.7 | 231.3 | 0.53 | 0.82 | 2.00 | 1.12 |
   | 32 | 657.6 | 319.3 | 503.6 | 0.49 | 0.77 | 2.00 | 1.12 |
   | 64 | 817.2 | 426.4 | 607.1 | 0.52 | 0.74 | 1.77 | 1.12 |

   O_DIRECT reads 512 byte sectors where the page cache reads 4096 byte
   pages, so a 4128 byte record costs it 4608 bytes rather than 8192: `amp`
   1.12 against 2.00, and 1.4 to 1.6x the throughput. It does not need the
   format changed, and what is left of the gap to fio is almost exactly the
   1.12.

   **Except when the working set fits in memory.** The same test over a 6 GiB
   archive, once the cache was serving most of it, put buffered at 632.1 and
   O_DIRECT at 534.9 with `amp` reading 0.18 -- eighty-two percent of the
   bytes never reached the drive. A cache hit cannot be beaten by making the
   miss cheaper. A 4 KiB record is 4128 bytes with its 32-byte header, so it
   always spans two pages. On the VM both raf and fio saturated the device
   anyway and the 2x cost nothing. On the KIOXIA it costs exactly what it
   says: `vsfio.sh` puts 4 KiB random read at 0.47-0.54 of fio at every
   worker count from 1 to 256, with `amp` reading 2.00, and p50 at 1 worker
   of 183 us against fio's 92. The same 2x shows up on 4 KiB durable append
   once the drive saturates -- 1.1x at 1 writer, 0.45x at 256 -- because each
   append dirties a page the next one has to write again. At 1 MiB both are
   0.9-1.0x, which is the same fact seen from the other end.
3. **Where does the drive's SLC cache run out, and is raf still the
   bottleneck after it?** A 990 PRO absorbs tens of GB at 4-6 GB/s then falls
   to native TLC speed. Short runs measure the cache.
4. ~~**How much of the raw device does raf hand through, and does that hold
   as the thread count rises?**~~ **Answered for sequential work.**

   Sequential read, every worker on its own stream (`seqscale.sh`), with
   `raf-od` reading the same segments through O_DIRECT and parsing them in
   the benchmark:

   | 4 KiB | fio | raf | raf-od | raf/fio | od/fio |
   |---|---|---|---|---|---|
   | 1 stream | 378.7 | 346.3 | 1386.2 | 0.91 | 3.66 |
   | 8 | 316.3 | 399.3 | **1999.2** | 1.26 | 6.32 |
   | 32 | 868.4 | 725.5 | 1867.2 | 0.84 | 2.15 |
   | 64 | 923.7 | 842.3 | 1817.6 | 0.91 | 1.97 |

   | 1 MiB | fio | raf | raf-od | raf/fio | od/fio |
   |---|---|---|---|---|---|
   | 1 stream | 142.9 | 313.1 | 1456.9 | 2.19 | 10.20 |
   | 8 | 318.2 | 415.6 | **2043.8** | 1.31 | 6.42 |
   | 32 | 762.3 | 776.6 | 1921.7 | 1.02 | 2.52 |
   | 64 | 911.3 | 947.0 | 1865.6 | 1.04 | 2.05 |

   raf matches fio at both sizes and converges on it as the load rises --
   0.84 to 1.31 across the sweep, 0.91 and 1.04 at sixty-four streams, `amp`
   1.00 throughout. An earlier sweep to 128 streams read 0.99.

   **Both of them get 45% of the drive**, and `raf-od` says why that is the
   shape rather than the code: 1817 to 2044 MiB/s, which is the O_DIRECT
   range below, reached with eight threads. raf's framing, its CRC and a copy
   out of the window are not a bottleneck -- a single O_DIRECT thread already
   reads 1386.

   | shape | MiB/s |
   |---|---|
   | O_DIRECT, psync, 8 threads | 1935 |
   | O_DIRECT, psync, 32 threads | 1923 |
   | O_DIRECT, io_uring, queue depth 64 | 1775 |
   | buffered, io_uring, queue depth 64 | 936 |
   | buffered, psync, 32 threads, 4 MiB blocks | 713 |
   | **buffered, psync, 32 threads -- raf's shape** | **733** |
   | buffered, psync, 8 threads | 302 |

   raf at 32 streams reads 725 to 776. **It is at the ceiling of the shape it
   uses, and O_DIRECT is a different ceiling rather than a faster road to the
   same one.**

   The rows vary queue depth and O_DIRECT independently, because which one
   costs the 2.5x decides what raf should do about it, and the answer is
   unambiguous: **every buffered row lands between 302 and 936 MiB/s whatever
   the engine, queue depth, thread count or block size, and every O_DIRECT
   row lands between 1775 and 1935.** Buffered io_uring at depth 64 reads
   936, no better than psync's 733. It is not the queue depth. It is also not
   page-cache reclaim: an 8 GiB file on a 31 GiB machine gives 733 against
   the 46 GiB file's 751.

   So a batched or asynchronous read API would not help raf's sequential read
   at all, and O_DIRECT doubles it with eight synchronous threads, which raf
   already has. No format change is needed either: this drive's logical block
   is 512 bytes, so an aligned window costs at most 511 bytes at each end --
   it is the page cache, not the drive, that rounds a 4128 byte record up to
   two 4096 byte pages.

   What O_DIRECT costs is **not** a copy, though an earlier reading of these
   numbers said it was. A buffered pread into the caller's string is the
   kernel copying out of the page cache, so a miss costs one DMA and one copy
   whichever path it takes; O_DIRECT moves that copy out of the kernel rather
   than adding one.

   It could be fewer copies than today. O_DIRECT needs the destination
   aligned and the offset and length multiples of 512, and raf's payloads sit
   at 32*(k+1) mod 512 -- aligned one record in sixteen. Padding the meta to
   512 would align every payload and make every length a multiple of 512, so
   the drive could DMA straight into the caller's buffer: genuinely zero
   copies, which the buffered path cannot reach because `copy_to_user` is not
   optional. The price is 512 bytes a record rather than 32 -- 12.5% on a 4
   KiB payload -- and an API that hands back an aligned buffer instead of a
   std::string.

   And it costs less than losing the page cache sounds like it should,
   because **neither `odread` nor `odrand` caches anything** and both numbers
   above are theirs. `odread` slides a 1 MiB window and carries the
   straddling record forward -- that is the whole of its readahead, and one
   thread of it reads 1386 MiB/s. `odrand` issues one pread per record and
   keeps nothing between them, and still beats the buffered path by 1.4 to
   1.6x on a working set larger than memory. Self-managed caching is not a
   prerequisite for any of this; it is only what raf would need in order to
   win the one case it loses, a working set that fits in RAM, and
   reimplementing the page cache to win that case is rarely a good trade.

   Page-aligning records, considered and dropped: padding a record to 8192
   aligns where the record starts, not where the payload starts. The payload
   still begins 32 bytes in and still spans two pages, so `amp` stays 2.00
   and the padding buys nothing. With a 4096 byte payload the only layout
   that fixes random-read amplification is one that stops storing the meta
   next to the payload. Sequential reads never had the problem: `amp` is 1.01
   there, because neighbouring records share pages.

   One machine, one drive. The buffered ceiling in particular may be this
   box's -- it runs kubelet and a VM image off the same filesystem.

   Taken with the random-read numbers above, buffered I/O has no throughput
   advantage anywhere raf was measured on a working set larger than memory:
   sequential 2.2 to 5x for O_DIRECT, random 1.4 to 1.6x. Its one advantage
   is the page cache hit, and that is worth everything when the working set
   fits and nothing when it does not. The question is not which is faster but
   what raf's working set is expected to be against RAM -- which is a product
   question, not a measurement.

   Sequential 1 MiB durable append reaches 1209 MiB/s at eight writers with
   raf/fio at 1.04. 4 KiB durable append is still open, below.

5. **What is the 8.8 ms append?** At 4 KiB with two to eight writers, p50
   pins to 8.8 ms and barely moves: 8847, 8784, 8762 across worker counts,
   and 8825, 8828, 8814 with the frontier write disabled. Three suspects are
   eliminated at the magnitude where it appears -- measurement order, page
   alignment, and the frontier write -- and the journal counters are
   identical to fio's at every worker count, so raf asks for no more journal
   work than fio does. **fio lands in the same mode**, 8737 us at four
   writers, which says it is the system's and not raf's.

6. **The drive degrades over a session and does not recover.** The same
   machine, the same test at four writers: 11.5 MiB/s for fio and 11.4 for
   raf early on, 1.7 and 1.7 after a few hundred GiB. Both sides fall
   together, so ratios taken back to back stay meaningful while absolute 4
   KiB write numbers do not. Any 4 KiB write figure in this repo should be
   read as "on a drive in whatever state that session's writes had left it".

## Where raf stands against the drive

One machine, a KIOXIA EXCERIA G2, measured over a session that wrote several
hundred gigabytes to it. The drive degrades as that goes on -- its streaming
write ceiling read 631 MiB/s at the end against 1209 for a durable append
earlier the same day -- so **the absolute numbers are a floor and the ratios,
taken back to back, are what hold.**

### Sequential read: at the drive, with `directReads`

| | MiB/s | of the drive |
|---|---|---|
| drive, O_DIRECT | 1900 | 100% |
| **raf, `directReads`, 8 readers** | **1953** | **100%** |
| fio, buffered, 64 jobs | 907 | 48% |
| raf, buffered, 64 readers | 837 | 44% |

Buffered, raf tracks fio from one reader to 128 -- 0.83 to 1.18, 0.99 at 128
-- and neither reaches the drive, because the page cache caps this machine at
733 to 936 MiB/s whatever the engine, queue depth, thread count or block
size. `directReads` crosses that cap with eight synchronous readers.

### Random 4 KiB read: close to fio, and fio is at the drive

| | MiB/s | of the drive |
|---|---|---|
| drive, random 4 KiB | 822 | 100% |
| fio, 64 jobs | 791 | 96% |
| **raf, `directReads`, 64 readers** | **623** | **76%** |
| raf, buffered, 64 readers | 424 | 52% |

Buffered is a flat 0.5 of fio at every worker count, which is `amp` 2.00: a
4096 byte payload with a 32 byte header spans two pages and the page cache
reads pages. `directReads` reads 512 byte sectors instead -- `amp` 1.12 --
and recovers most of it. What is left is the 1.12 itself plus the CRC and the
copy, which is work fio does not do at all.

### Durable append: the drive is not the limit, the journal is

One run, eleven worker counts, 4 KiB records, throughput and device bytes
measured together at each point:

| writers | fio MiB/s | raf MiB/s | raf/fio | fio amp | raf amp | amp ratio |
|---|---|---|---|---|---|---|
| 1 | 6.0 | 5.8 | 0.97 | 7.20 | 8.13 | 1.13 |
| 2 | 6.6 | 6.0 | 0.91 | 7.12 | 7.85 | 1.10 |
| 4 | 11.1 | 10.7 | 0.96 | 5.56 | 6.49 | 1.17 |
| 8 | 23.3 | 20.6 | 0.88 | 4.90 | 5.80 | 1.18 |
| 16 | 42.3 | 40.8 | 0.96 | 4.38 | 5.28 | 1.21 |
| 32 | 43.1 | 69.2 | 1.61 | 3.99 | 4.94 | 1.24 |
| 64 | 77.6 | 111.8 | 1.44 | 3.27 | 4.09 | 1.25 |
| 128 | 201.1 | 45.0 | 0.22 | 2.69 | 3.82 | 1.42 |
| 256 | 100.9 | 67.7 | 0.67 | 2.75 | 3.74 | 1.36 |
| 512 | 123.6 | 82.2 | 0.67 | 2.64 | 3.61 | 1.37 |
| 1024 | 128.9 | 103.7 | 0.80 | 2.50 | 3.52 | 1.41 |

**raf writes one extra page per record, and that is the whole structural
difference.** Subtract the columns rather than dividing them: raf - fio is
0.93, 0.73, 0.93, 0.90, 0.90, 0.95, 0.82, 1.13, 0.99, 0.97, 1.02 payload
bytes, which is 4096 bytes within measurement noise at every concurrency from
one writer to a thousand. A 4096-byte payload with a 32-byte header spans two
4096-byte pages and buffered writes go out a page at a time.

The *ratio* moves from 1.13 to 1.41 only because the cost both sides share
shrinks: journal transactions fall from 1.001 per flush at one writer to
0.002 at 1024, as more appends batch into one commit. A prediction of 1.12
matches the low-concurrency end, and gets there for the wrong reason -- it is
not a 512-byte block, it is a whole page against a journal bill that happens
to be six times larger.

Throughput tracks that, with one exception: **raf is 0.88 to 1.61 of fio from
one worker to 64** -- ahead of it at 32 and 64 -- and 0.67 to 0.80 from 256
up. The 128-worker row is not to be trusted: fio's 201.1 is its highest
reading anywhere and `batch32` drops from 1118 to 410 at the same point.

batch32's amplification is 1.26 at one writer and 1.09 from 64 up, and its
throughput reaches four figures. Those are burst numbers -- 256 writers times
1024 appends is a gigabyte, which this drive's cache absorbs -- so read them
as a direction, not a rate.

Preallocation is the one variant that does not improve with concurrency --
its amplification is flat at 4.05 to 4.11 while everything else falls -- and
its throughput is 4.9 to 13.0 MiB/s against raf's 22.2 to 56.2. It removes
the journal work (0.001 to 0.003 transactions per flush against 0.008 to
0.250) and spends more than it saves on the zeros. **Leave it off.**

Asking for the flush the other way changes nothing: fio with `--sync=dsync`,
which is what raf opens with, reads 14.7, 88.4 and 89.9 MiB/s at eight, 64
and 256 writers against 13.3, 87.2 and 83.2 for `--fdatasync=1`.

Nor does a deeper queue. One thread with 64 O_DSYNC writes outstanding
through io_uring retires 1363 4 KiB appends a second; sixty-four files at
depth one retire 4155, and sixty-four at depth four retire 7634 -- file count
is what moves it, and even the best of those is a third of the 23398 that 64
plain psync threads manage. **An asynchronous append API would not help.**

**This drive is no longer in a state where that can be resolved.** A single
durable append read 1.7 MiB/s for fio here against 5.8 earlier the same day
on the same command; the session has written well over a terabyte to it.
Every number on this page is a floor, and the write numbers are the worst
affected. Settling the 11 ms mode needs a drive that has been left alone, or
trimmed, first.

The 1 MiB durable rows in `seqscale.sh --what write` are not trustworthy as
they stand: 64 MiB per worker is 64 operations, and 512 MiB of burst fits in
the drive's cache -- one row read 1216 MiB/s, above the measured streaming
ceiling, which cannot be a sustained rate. That needs a bigger budget before
it means anything.

## Running it

```sh
git clone <this repo> && cd raf
sudo mkdir -p /mnt/raf-bench && sudo chown "$USER" /mnt/raf-bench   # on the drive under test

cd bench/physical
sudo ./setup.sh --mount /mnt/raf-bench --tune --out ~/raf-results
     ./run.sh   --mount /mnt/raf-bench            --out ~/raf-results
sudo ./setup.sh --mount /mnt/raf-bench --restore --out ~/raf-results
```

Then send back **both** `~/raf-results/results.txt` and
`~/raf-results/env.txt`. The second one is not optional: a drive that was 90%
full, thermally throttled, or running `mq-deadline` explains more than any
table, and without it a surprising number cannot be told from a broken one.

### What needs root

| script | root |
|---|---|
| `setup.sh` | yes for `--tune` and `--restore`; the report alone runs as you |
| `run.sh` | only the `read` section, to drop the page cache. `--only write,slc` needs none |
| `sustained.sh` | **no** |
| `appendcost.sh` | **no** |
| `appendscale.sh` | **no** |
| `vsfio.sh` | **no**. It drops the page cache with `posix_fadvise`, not `/proc/sys/vm/drop_caches` |
| `diagnose.sh` | no. Under sudo it fills in the drive's model, write-cache flag and wear; without it those lines are skipped rather than prompted for |

Temperature comes from sysfs in every case, so no script shells out to
`nvme` just to read it.

### Requirements

- cmake and a C++20 compiler (C++23 is used where available)
- **spdlog**, the library's one hard dependency. If cmake cannot find it, it
  is downloaded automatically, so no package manager is needed -- but a
  distro copy is faster: `apt install libspdlog-dev`, `dnf install
  spdlog-devel`, `brew install spdlog`. Build with `-DRAF_FETCH_DEPS=OFF` to
  require a local copy instead of downloading. (GoogleTest is handled the
  same way, and `run.sh` builds with tests off anyway.)
- `liburing` for the io_uring rows. If it is in a local prefix, point
  pkg-config at it: `PKG_CONFIG_PATH=/opt/liburing/lib/pkgconfig ./run.sh ...`
  Without it those rows print `-` and the rest still runs.
- `fio` and `jq` for the reference section; skipped with a note if missing.
- Free space of at least 2x RAM plus headroom. `setup.sh` checks and warns.

**If conda is active** (a `(base)` prefix on your shell), deactivate it first.
Conda ships its own compiler and libstdc++, and a benchmark built against
those is not measuring the system toolchain:

```sh
conda deactivate
```

### Options

| flag | meaning |
|---|---|
| `--only write,read,slc,fio` | run a subset |
| `--quick` | smaller counts; a sanity pass, not a result |
| `--reps N` | repetitions per point, median reported (default 3) |
| `--set-gib N` | override the cold working set; **must exceed RAM** |

The full run writes roughly 2x RAM for the read section plus 128 GiB for the
sustained-write section, and takes a few hours. `--only write` alone answers
question 1 in minutes.

### Check what you are about to mkfs

`--mount` can be a plain directory on the root filesystem, and `findmnt -T`
is the only way to tell:

```sh
findmnt -T /mnt/raf-bench
```

If `SOURCE` is the root partition, nothing in this directory should be given
a device argument -- no `tune2fs`, no `mkfs`, no `mount -o`. None of these
scripts take one, and none of them should be made to.

The filesystem here is default ext4 and stays that way, so the durable-append
cliff cannot be tuned away underneath raf. The two levers that remain are in
raf itself: batching, which `appendBatch` already provides, and preallocating
segments so appends overwrite rather than extend.

## How close is raf to the device?

```sh
./vsfio.sh --mount /mnt/raf-bench --out ~/raf-results          # a few hours
./vsfio.sh --mount /mnt/raf-bench --workloads rr4k,sw4k \
           --workers "1 16 256" --reps 3                       # the short version
```

fio over a plain file is the floor: the same system calls, no format, no
checksum, no index. Six workloads -- 4 KiB and 1 MiB, random read, sequential
read and durable append -- each swept 1, 2, 4 ... 256 workers, with fio and
raf run back to back at every point so both see the same drive.

What makes the two sides comparable, and where they are not:

- fio runs `ioengine=psync`, because that is what raf's posix io layer does.
  An io_uring fio number would be measuring a different program.
- Both sides are durable on writes: raf opens `O_DSYNC`, fio gets
  `--fdatasync=1`. fio's `clat` stops before the flush, so the reported p50
  adds fio's sync latency back in. Without that fio looks ten times faster
  than it is.
- raf writes 4128 bytes per 4 KiB record and fio writes 4096. A few percent
  of any write gap is that, by construction.
- Caches are dropped on both sides the same way, with `posix_fadvise`
  (`DONTNEED`) rather than fio's own `--invalidate`, which would have each of
  W jobs evicting what the others just read.

The dataset defaults to 1.5x RAM so a dropped page cache is really cold; the
drive's own cache is out of reach either way, and the script says so when
`--gib` is below RAM. Reading `raf/fio` close to 1.00 means the format costs
nothing measurable; a ratio that falls as workers rise is raf serialising
somewhere, and the latency columns say whether it is queueing or a stall.

| flag | meaning |
|---|---|
| `--workloads rr4k,rr1m,sr4k,sr1m,sw4k,sw1m` | pick a subset |
| `--workers "1 16 256"` | the sweep (default 1 2 4 ... 256) |
| `--gib N` | dataset size; should exceed RAM |
| `--write-mib N` | bytes per worker in the write sweep (default 16) |
| `--ops4k N` / `--ops1m N` | total operations per read point, split across workers |
| `--reps N` | repetitions per point, best by throughput (default 2). Keep it even: it is what alternates which side goes first |

### Why does the append stop scaling at sixteen writers?

```sh
./appendscale.sh --mount /mnt/raf-bench --out ~/raf-results
```

raf gains nothing between one writer and sixteen while fio nearly triples,
and raf's latency rises almost exactly 16x -- work that serialises. Two
explanations are already ruled out: measurement order, and page alignment.
The script runs six variants at each worker count -- fio as the floor, raf as
shipped, with preallocation (no metadata commit per append), without the
frontier write (`RAF_PUBLISH_FRONTIER=0`, one write per append instead of
two), both, and `batch32` as the ceiling. Whichever variant restores scaling
names the cost; if none does, it is somewhere this script does not look.

`RAF_PUBLISH_FRONTIER=0` is a measurement switch rather than a feature. With
it off a reader calls a damaged record end-of-data instead of damaged, which
is a worse diagnostic, not a wrong answer.

### If a number looks wrong, diagnose before re-running

```sh
./diagnose.sh --mount /mnt/raf-bench
```

Under a minute, ~100 MiB written. It prints the device-mapper stack, mount
options, NVMe write-cache and APST settings, and then splits one 4 KiB write
three ways -- `O_DIRECT` alone, `O_DIRECT|O_DSYNC`, and buffered with
`fdatasync` -- so the cost lands on the flash, the flush, or the filesystem
rather than on "the disk is slow". A healthy NVMe is 10-50 us for all three;
anything in the milliseconds has a cause worth finding before the long run.

### If something is off

- **`amp` below 1.0** means reads were served from the page cache, so the set
  was not larger than RAM. Raise `--set-gib`.
- **io_uring rows all `-`** means pkg-config could not find liburing.
- **Latency percentiles that swing wildly between reps** usually mean the CPU
  governor is not `performance`, or something else is using the drive.
- **`cannot write .../results.txt`** means an earlier `sudo ./setup.sh` left
  the output directory root-owned. The script now chowns it back, but to fix
  an existing one: `sudo chown -R "$USER" ~/raf-results`.

## What the scripts do

`setup.sh` records the machine (CPU, RAM, kernel, drive model and firmware,
PCIe link, queue settings, NVMe wear and temperature, filesystem options) into
`env.txt`, then checks the things that quietly invalidate a measurement:
rotational flag, I/O scheduler, readahead, CPU governor, virtualisation, free
space, and how full the filesystem is. `--tune` sets `scheduler=none`,
`read_ahead_kb=0` and `governor=performance`, saving the old values;
`--restore` puts them back.

`run.sh` builds `raf_matrix` and runs four sections. `raf_matrix` reports
latency percentiles alongside throughput, and for reads it brackets the run
with `/proc/diskstats` so it can report bytes-moved over bytes-returned. Its
`scan` mode writes the index list to a side file so the cold read phase never
has to walk the archive first -- that walk would warm the cache and turn a
cold measurement into a warm one.

`vsfio.sh` runs the same `raf_matrix` binary beside fio, using its `seqread`
mode for iteration and its `read` mode for random lookups. Write points get a
fresh archive and fresh fio files each time: an append that extends a file
costs differently from one that overwrites, and reusing files would turn half
the sweep into the other measurement.

Both are deterministic: payload bytes come from the record number, writers
start together on a `std::latch`, and the random-read order is a fixed
coprime stride. Two runs of the same arguments touch the same records in the
same order, so a difference between runs is a real difference.
