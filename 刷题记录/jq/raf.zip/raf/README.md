# raf — record archive file

An append-only store for opaque binary records, built to the design in
`docs/stage3.md`. A writer appends; readers walk the archive in order or jump
straight to a record by index. `append()` returning means the record is on
stable storage.

```cpp
#include <raf/raf.h>

raf::RecordWriter writer("/var/lib/events");
const raf::INDEX_TYPE index = writer.append(payload);   // durable on return

raf::RecordReader reader("/var/lib/events");
std::optional<std::string> one = reader.read(index);    // random lookup
while (std::optional<std::string> next = reader.readNext()) { ... }  // walk
```

## Layers

The three layers of the design doc -- the doc calls them frontend, middle and
backend -- one directory each, and nothing reaches past its neighbour.

| Layer | Directory | Owns |
|---|---|---|
| `api` | `src/api` | `RecordWriter`, `RecordReader`, the durability and ordering contracts, thread safety |
| `store` | `src/store` | The file format: segment files, record headers, recovery scans, the archive directory |
| `io` | `src/io` | Every system call: `pwritev`/`preadv`, `flock`, `fsync`, directory reads |

`IoBackend` is an interface with two implementations: `posixBackend()`, the
default, and `uringBackend()`, built when `-DRAF_URING=ON` and selected at run
time with `RAF_BACKEND=uring`. The layers above name no POSIX API, so the swap
touches nothing but the one line in `defaultBackend()`.

io_uring is off by default because measuring it says it should be. A returning
append is a durable append, so a backend call cannot return before its
completion arrives -- every operation is submit-then-wait, depth one, and the
ring has nothing to batch. `strace -c` counts one `io_uring_enter` per append
against one `pwritev`: the same syscall count, plus a ring. Worse, an `O_DSYNC`
write cannot complete inline, so io_uring hands it to an `iou-wrk` kernel
worker -- one writer thread spawns 16 of them -- and pays a context switch per
record. On tmpfs, where no device latency hides that cost, 4 KiB durable
appends run 2756 MiB/s on POSIX and 533 MiB/s on io_uring. On a disk slow
enough that 1.5 ms of device latency swamps 7 us of handoff the two are even,
which is the only reason io_uring looks free here. Reads are a different story
-- a cached read completes inline, no worker involved, and the two backends
land within 1% of each other.

io_uring starts paying when a backend call is allowed to return before the
write lands, which means group commit across callers, not a different system
call underneath the same synchronous interface.

## On disk

An archive is a directory of segment files, `seg-00000.raf` upward. Each holds
a 64-byte header and then records back to back:

```
SegmentHeader | RecordMeta payload | RecordMeta payload | ...
```

`RecordMeta` is 32 bytes and carries **two** checksums, which answer different
questions:

* `meta_crc` covers the 28 bytes before it — the header minus itself. It is
  what lets a reader trust `length` before it has read, or even allocated for,
  the payload.
* `data_crc` covers the payload, and is checked once the payload is in hand.

One checksum over both would mean trusting a length that nothing had vouched
for yet.

A record's header and payload go to the kernel in a single `pwritev` against a
descriptor opened `O_DSYNC`, so one write makes the whole record durable. There
is no flush step and nothing to call after `append()`.

Buffered `O_DSYNC` rather than the `O_DIRECT | O_DSYNC` the doc's measurements
favour, deliberately: `O_DIRECT` requires the buffer, the offset and the length
to be sector-aligned, which for records of arbitrary size means padding every
record and bouncing every payload through an aligned buffer. That is exactly
the copy this implementation is built to avoid. `O_DIRECT` belongs behind the
backend interface, alongside io_uring, where it can own its own aligned
buffers.

### One writer, one segment

Each writer takes a segment for itself with `flock` and never shares it. That
is the design doc's "concurrent data writes v2": writers do not queue behind
one another, do not copy their payloads into a shared queue, and a writer that
dies takes nothing else down with it — the kernel drops its lock and the next
writer adopts the segment and recovers it.

Because `flock` conflicts between open file descriptions rather than between
processes, the same lock separates two threads and two processes.

A single `RecordWriter` serializes its own appends, which is what the
synchronous API already implies. **More write throughput means more writers,
one per thread**, not more threads on one writer.

### Indexes

`INDEX_TYPE` is a 64-bit integer: 15 bits of segment id in 62..48, 48 bits of
offset in 47..0. Bit 63 stays clear, so every valid index is non-negative and a
negative one is unambiguously a mistake. That allows 32768 segments — and so
32768 concurrent writers — of 256 TiB each.

### Recovery

Opening a segment for writing scans it: walk the records, stop at the first
byte that is not the start of a complete one, and truncate there. A trailing
fragment belongs to an append that never returned, so dropping it loses nothing
the API promised.

A payload that fails its checksum with a good record behind it is a different
thing — that is damage, not a torn tail, and the scan steps over it rather than
throwing away the records after it. A record header that fails its checksum
with more than one record's worth of file behind it gets the same treatment,
except that nothing can say where the next record starts, so iteration of that
segment stops. Direct lookups past the damage still work.

## Iteration order

With several writers on several segments:

* Records that were already complete when a reader opened come out in one
  order, and **every reader that opens on the same segment tails walks them in
  that same order**.
* Records appended after that keep **the order of the writer that wrote them**;
  no order is defined between writers.

A reader that has caught up is not finished: a later `readNext()` picks up
records appended since, and segments created since — including by writers that
started after the reader did.

Each segment keeps one record header prefetched; the merge compares those
headers' timestamps to decide who goes next. Reading a payload picks up the
following header in the same `preadv`, so iteration costs one system call per
record and never copies the payload.

## One system call per record, no extra copies

Payloads are never assembled, staged or duplicated:

* `append()` and `appendBatch()` point iovecs straight at the caller's buffers.
  The only bytes raf builds are the 32-byte record headers.
* `appendBatch(const std::vector<std::string>&)` builds a vector of
  `string_view`, not a vector of strings.
* Reads land directly in the `std::string` that is returned, sized without
  zeroing it first. That zeroing is what C++23's `resize_and_overwrite` avoids,
  and it is worth 15 µs on every 1 MiB record; under C++20 the code falls back
  to `resize()` and pays it.
* Scratch vectors are reused across appends, so a steady stream of appends
  allocates nothing.

Both read paths reach one system call per record, and neither gives up the
first point to do it:

* **Iteration** reads a payload and the header that follows it in one
  `preadv` — two iovecs, the payload going straight into the string to be
  returned.
* **Random reads** cannot know a record's length until they have read and
  checked its header, which is a system call before the payload read can start.
  So they guess: records in one segment come from one writer and tend to be the
  same size, so a segment remembers the last length it served and scatters the
  header and that much payload in a single `preadv`. A correct guess is one
  call; a guess that runs short falls back to reading the payload exactly, no
  worse than not guessing at all. Records past 64 KiB are not guessed at, since
  by then the second call is lost in the payload anyway.

Measured with `strace`: 1005 `preadv` for 1000 records iterated, 101 for 100
random lookups.

## Extending the file is the expensive part

Measured on a KIOXIA EXCERIA G2 (consumer NVMe, no power-loss protection),
4 KiB durable writes, 32000 of them, throughput per 4000-write chunk:

| | first chunk | steady state |
|---|---|---|
| overwriting blocks that already exist | 360 us | **360 us, flat** |
| extending the file -- what raf does | 957 us | **4500 us** |
| raf `appendBatch`, 32 records per call | 176 us/record | **176 us/record, flat** |

The drive is not the problem: overwriting runs at 360 us per durable write
and never degrades. Extending the file does, by 12.5x, because every append
makes ext4 commit a size change and the journal reaches a state it does not
come back from -- a 60 second idle does not recover it. raf never
preallocates, so every `append()` extends.

Two consequences. **Batching is not an optimization here, it is the
difference between 0.9 and 21 MiB/s**, and `appendBatch` already provides
it: one flush and one metadata commit per call instead of per record.

**Preallocating segments turns appends into overwrites**, and `Options::
preallocateBytes` does that. On a consumer NVMe it is worth about 1.85x, and
it holds: that drive falls off a cliff under sustained small durable writes
whether preallocation is on or not, and the ratio survives the fall.

| 4 KiB durable append | extends the file | overwrites | ratio |
|---|---|---|---|
| before the cliff | 613 us | **335 us** | 1.84x |
| after the cliff | 4427 us | **2128 us** | 1.89x |

The cliff is the device's, not the option's -- it took 30000 records to
reach without preallocation and 22000 with, and no amount of idling brings
it back. It is off by default anyway, because it writes twice the bytes:
nothing to gain where a flush is already cheap, flash endurance to lose, and
the cliff arrives sooner counted in records even though it arrives later
counted in device bytes, the zeros being large sequential writes.

Making that work at all needed a different end-of-data rule, since
preallocation destroys the one thing the old one rested on. A segment
now publishes its append point into its header after each append lands, and
a header that fails its checksum below that frontier is damage while the
same bytes at or above it are an unfinished write. File length no longer
enters into it.

None of this is visible on a slow disk. On the QEMU SCSI disk this project
was developed against, overwriting measured *slower* than extending, and the
curve was flat.

## Checksums

CRC-32C over every record header and every payload, on the SSE4.2 `crc32`
instruction where the CPU has it. That instruction retires one operation per
cycle but takes three to produce its answer, so a single chain of them — each
waiting on the one before — wastes two thirds of the throughput. raf runs three
chains over three slices of each 3 KiB block and folds them back together with
precomputed GF(2) shifts, which is exact rather than approximate: 31 GiB/s
instead of 11.5.

## Errors

| Kind | Exception |
|---|---|
| Caller's mistake — closed writer, oversized record, negative index | `std::logic_error` |
| Failed system call — no permission, out of space, unreadable archive | `std::system_error` |

`read()` returns `std::nullopt` for an index with nothing readable at it: never
written, or written and since damaged. A damaged record is never returned as a
value.

A write that fails partway rolls the segment back to the last record boundary,
so nothing half-written is left behind and the writer keeps working once the
underlying problem is gone.

## Building

Needs CMake 3.16, spdlog, and GoogleTest for the tests. C++23 is used where the
compiler has it and C++20 otherwise; pass `-DCMAKE_CXX_STANDARD=20` to force
the older one.

```sh
cmake -S . -B build
cmake --build build -j
ctest --test-dir build
./build/raf_bench
```

| Option | Default | |
|---|---|---|
| `RAF_URING` | `OFF` | build the io_uring backend; needs liburing |
| `RAF_BUILD_TESTS` | `ON` | build `raf_test` |
| `RAF_BUILD_BENCH` | `ON` | build `raf_bench` |
| `RAF_SANITIZE` | `OFF` | address + undefined sanitizers |
| `RAF_TSAN` | `OFF` | thread sanitizer |
| `RAF_LOG_LEVEL` | `info` | lowest level compiled in; below it the calls vanish |

## Logging

`<raf/raf.h>` does not mention spdlog. An application that wants raf's
diagnostics includes `<raf/logging.h>` and calls `raf::setLogger()`. By default
raf reports warnings and above to stderr: damaged records, recovered segments,
segment files it could not make sense of. The levels below `RAF_LOG_LEVEL` are
compiled out, so the append path does not carry their string literals.

## Tests

`ctest --test-dir build`, or `./build/raf_test` for the detail. Nothing in the
suite uses random data or sleeps: payloads are a pure function of
`(writer, sequence, size)`, threads meet at `std::latch`, and processes meet at
pipe-backed gates, so a failure reproduces.

| File | |
|---|---|
| `test_crc32c.cpp` | check values against a bit-at-a-time reference at every length, across the interleaved block boundaries |
| `test_format.cpp` | header layout, what each checksum covers, index packing |
| `test_backend.cpp` | scatter/gather past `IOV_MAX`, short reads, locking, directories |
| `test_segment.cpp` | the format end to end: scans, torn tails, damage, prefetch, read speculation |
| `test_api.cpp` | the contract: return values, durability, calls out of order |
| `test_boundary.cpp` | empty and maximum records, batch and segment boundaries, bad lengths |
| `test_errors.cpp` | refused opens, a write that runs out of room, damage on disk |
| `test_recovery.cpp` | crashes by `_exit` and `SIGKILL`, files cut at every interesting byte |
| `test_iteration.cpp` | the ordering contract, including the doc's worked example |
| `test_concurrency.cpp` | threads writing, reading and reopening together |
| `test_multiprocess.cpp` | segment ownership, takeover after a crash, cross-process visibility |
| `test_stress.cpp` | the same checks run wide; `RAF_STRESS_SCALE=n` for a longer soak |

The suite passes clean under `-fsanitize=address,undefined` and
`-fsanitize=thread`.
