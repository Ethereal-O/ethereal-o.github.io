# The short suite

One file, 24 tests, under two seconds:

```sh
cmake -B build -DRAF_BUILD_TESTS=ON && cmake --build build -j
./build/raf_core_test
```

`raf_test` next door has 160. This one holds the subset where a failure means
**a record was lost, duplicated, reordered, handed back wrong, or never there
at all**. Everything else is in the long suite, which is the one to run
before shipping.

## What is in it

| | |
|---|---|
| durability | an append that returned is on disk; an index reads back what it named; a batch is all of it or none |
| iteration | one writer comes back in append order; two readers agree on what was there when they opened; a reader that ran out looks again; a writer still in flight does not hide another segment's records |
| extremes | empty and largest records; over the limit is refused before anything is written; rolling to a new segment keeps the order |
| damage | a bad payload is never returned; a bad header stops the walk instead of guessing where the next record starts; one broken segment does not cost the others |
| recovery | records survive SIGKILL; a file cut at any point recovers to a record boundary and is trimmed there; records written after recovery do not overwrite the old ones |
| concurrency | a writer per thread, each record exactly once; a shared reader hands each record to one caller; readers and writers running together |
| processes | two processes never share a segment; a dead process's segment is taken over |
| checksum | CRC-32C against its definition at every length |
| O_DIRECT | iteration and random lookup agree at sizes that are multiples of nothing; a record larger than the window still reads back |

## What is left out, and why

- **The API's manners.** Double close, move construction, `string_view`
  overloads, which exception a missing directory throws, a path that is
  really a file, a directory with no write permission. Breaking any of them
  is a bug; none of them loses a record.
- **Layers below the contract.** The POSIX and io_uring backends, directory
  operations, the format structs' sizes, segment file naming. They are
  reached through everything above.
- **Store internals.** Read speculation, the published frontier's four
  cases, scan counters, the window's byte accounting. These are how the
  promises are kept rather than what they are -- except where getting them
  wrong is invisible from above, which is why the window's amplification
  tests stay in the long suite and are worth running.
- **Injected failures.** `tests/test_faults.cpp` makes a write land halfway
  and an fsync fail. Load-bearing, slow to reason about, and not a smoke
  test.

## Whether the selection is any good

Checked by breaking the library on purpose and seeing whether this suite
notices:

| mutation | caught |
|---|---|
| payload checksum not verified | `ADamagedPayloadIsNeverReturned` |
| header checksum corrupted on write | 40 of 24 assertions, everywhere |
| short reads retried (the real O_DIRECT bug, `91402f0`) | `ReadersAndWritersRunTogether`, every run |
| recovery leaves the torn tail on the file | `AFileCutAtAnyPointRecoversToARecordBoundary` |
| append timestamps allowed to go backwards | **no** |

The last one is deliberate rather than a hole. Within a segment a cursor
advances by offset, so the timestamp never decides that order; between
writers no order is promised. The clamp protects a store invariant that no
user-visible promise rests on, and `SegmentTest.AppendTimestampsNeverGoBackwards`
in the long suite is where it belongs.

The third row is the one worth noting: that bug was found by
`ReadersAndWritersRunTogether` and nothing else, which is why a test that
looks like a stress test is in a suite this short.
